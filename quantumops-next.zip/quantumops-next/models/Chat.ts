import { Schema, model, models } from "mongoose";

// Generic in-chat form submissions -- the analogue of the reference project's
// `forms(formdata)` table, but keyed to the authenticated user and form type
// instead of accepting an arbitrary client-supplied blob.
const ChatFormSubmissionSchema = new Schema({
  userId: { type: String, required: true, index: true },
  formId: { type: String, required: true },
  data: { type: Schema.Types.Mixed, required: true },
  createdAt: { type: Date, default: Date.now },
});

export const ChatFormSubmission =
  models.ChatFormSubmission ?? model("ChatFormSubmission", ChatFormSubmissionSchema);

// Thumbs up/down on assistant answers -- lets you see which answers to improve.
const ChatFeedbackSchema = new Schema({
  userId: { type: String },
  rating: { type: String, enum: ["up", "down"], required: true },
  userMessage: { type: String },
  assistantMessage: { type: String },
  createdAt: { type: Date, default: Date.now },
});

export const ChatFeedback = models.ChatFeedback ?? model("ChatFeedback", ChatFeedbackSchema);
