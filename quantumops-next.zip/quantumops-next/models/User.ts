import { Schema, model, models, type Document } from "mongoose";

export interface IUser extends Document {
  name: string;
  email: string;
  company?: string;
  hashedPassword: string;
  plan: "pilot" | "facility" | "enterprise";
  backendsConnected: number;
  alertFidelityThreshold: number;
  alertEmail?: string;
  pilotStatus: "NOT_REQUESTED" | "IN_REVIEW" | "APPROVED" | "REJECTED";
  createdAt: Date;
}

const UserSchema = new Schema<IUser>({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  company: { type: String },
  hashedPassword: { type: String, required: true },
  plan: { type: String, enum: ["pilot", "facility", "enterprise"], default: "pilot" },
  backendsConnected: { type: Number, default: 0 },
  alertFidelityThreshold: { type: Number, default: 0.94, min: 0.5, max: 0.999 },
  alertEmail: { type: String },
  // APPROVED / REJECTED are only ever set by a human on the admin side.
  pilotStatus: { type: String, enum: ["NOT_REQUESTED", "IN_REVIEW", "APPROVED", "REJECTED"], default: "NOT_REQUESTED" },
  createdAt: { type: Date, default: Date.now },
});

export const User = models.User ?? model<IUser>("User", UserSchema);
