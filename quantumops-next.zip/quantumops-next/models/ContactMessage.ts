import { Schema, model, models, type Document } from "mongoose";

export interface IContactMessage extends Document {
  name: string;
  email: string;
  message: string;
  createdAt: Date;
}

const ContactMessageSchema = new Schema<IContactMessage>({
  name: { type: String, required: true },
  email: { type: String, required: true },
  message: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

export const ContactMessage =
  models.ContactMessage ?? model<IContactMessage>("ContactMessage", ContactMessageSchema);

export interface IEarlyAccessSignup extends Document {
  email: string;
  role?: string;
  createdAt: Date;
}

const EarlyAccessSignupSchema = new Schema<IEarlyAccessSignup>({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  role: { type: String },
  createdAt: { type: Date, default: Date.now },
});

export const EarlyAccessSignup =
  models.EarlyAccessSignup ?? model<IEarlyAccessSignup>("EarlyAccessSignup", EarlyAccessSignupSchema);
