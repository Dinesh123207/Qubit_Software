/**
 * Run with: npm run seed
 * Creates one test account: test@quantumops.dev / password123
 */
import { config } from "dotenv";
config({ path: ".env.local" });
import bcrypt from "bcryptjs";
import { dbConnect } from "../lib/db";
import { User } from "../models/User";

async function main() {
  await dbConnect();

  const email = "test@quantumops.dev";
  const existing = await User.findOne({ email });
  if (existing) {
    console.log(`Already exists: ${email}`);
    process.exit(0);
  }

  const hashedPassword = await bcrypt.hash("password123", 10);
  await User.create({
    name: "Test User",
    email,
    company: "QuantumOps",
    hashedPassword,
  });

  console.log(`Created test account: ${email} / password123`);
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
