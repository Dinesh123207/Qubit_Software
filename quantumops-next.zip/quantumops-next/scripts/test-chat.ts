/**
 * Logic tests for the chat assistant -- pure modules only (no DB, no Next).
 * Run:  npm run test:chat
 */
import { bestMatch } from "../lib/faq";
import { FAQ } from "../lib/faqData";
import { STATES, resolveStateId, rootState, visibleChoices, nextOf, stateMessage } from "../lib/chatDialog";
import { FIELD_SPECS, isFieldKey, validateFieldWrite, formatFieldReply } from "../lib/chatFieldSpecs";
import { FORMS, isFormId, validateFormSubmission } from "../lib/chatForms";
import { rateLimit, _resetRateLimitForTests } from "../lib/rateLimit";

let passed = 0;
const failures: string[] = [];
function check(name: string, cond: boolean, extra = "") {
  if (cond) passed++;
  else failures.push(`${name}${extra ? " — " + extra : ""}`);
}

// ---- FAQ matcher ------------------------------------------------------------
const faqCases: [string, string | null][] = [
  ["how much does it cost", "pricing"],
  ["pricing?", "pricing"],
  ["what does it monitor", "monitors"],
  ["what is t1", "t1"],
  ["what is T2?", "t2"],
  ["explain decoder latency", "decoder"],
  ["how do i request a pilot", "pilot-how"],
  ["hi", "hello"],
  ["thanks!", "thanks"],
  ["what's my plan", "my-plan"],
  ["what is my pilot status", "my-pilot"],
  ["which vendors do you support", "vendors"],
  ["is my data safe", "security"],
  ["what is a surface code", "surface"],
  ["how is this different from riverlane", "competitors"],
  ["asdfghjkl", null],
  ["what is the capital of france", null],
  ["", null],
  ["the a is", null],
];
for (const [q, expected] of faqCases) {
  const m = bestMatch(q);
  check(`faq: "${q}"`, (m?.entry.id ?? null) === expected, `got ${m?.entry.id ?? null} (${m?.score.toFixed(2)}), want ${expected}`);
}
check("faq: unique ids", new Set(FAQ.map((f) => f.id)).size === FAQ.length);
check("faq: every @field answer is a valid key", FAQ.filter((f) => f.answer.startsWith("@field:")).every((f) => isFieldKey(f.answer.slice(7))));

// ---- dialog tree integrity (no dead ends, no dangling references) ----------------
for (const loggedIn of [true, false]) {
  const tag = loggedIn ? "user" : "guest";
  const ids = new Set(Object.keys(STATES));
  const exists = (id: string) => ids.has(resolveStateId(id, loggedIn));
  check(`dialog[${tag}]: root exists`, exists(rootState(loggedIn)));
  check(`dialog[${tag}]: home/more exist`, exists("home") && exists("more"));

  for (const st of Object.values(STATES)) {
    const where = `state ${st.id}`;
    stateMessage(st, { name: "Ada Lovelace" });
    if (st.autoTransitionState) check(`${where}: autoTransition target`, exists(st.autoTransitionState), st.autoTransitionState);
    if (st.choicesFrom) check(`${where}: choicesFrom target`, exists(st.choicesFrom), st.choicesFrom);
    if (st.awaitInput) {
      check(`${where}: awaitInput.next`, exists(st.awaitInput.next), st.awaitInput.next);
      check(`${where}: awaitInput.field`, isFieldKey(st.awaitInput.field) && FIELD_SPECS[st.awaitInput.field].writable);
      check(`${where}: awaitInput has Cancel`, st.choices.length > 0);
    }
    if (st.form) {
      check(`${where}: form exists`, isFormId(st.form));
      check(`${where}: form has autoTransition`, !!st.autoTransitionState);
    }
    const menu = st.choicesFrom ? STATES[resolveStateId(st.choicesFrom, loggedIn)] : st;
    const usable = visibleChoices(menu.choices, { fleet: true }).length > 0;
    check(`${where}: not a dead end`, usable || !!st.autoTransitionState || !!st.form);

    for (const c of st.choices) {
      const cw = `${where} / ${c.id}`;
      for (const sample of ["NOT_REQUESTED", "IN_REVIEW", "APPROVED", "REJECTED", null]) {
        const target = nextOf(c, sample);
        check(`${cw}: next(${sample}) exists`, exists(target), target);
      }
      if (c.queryField) check(`${cw}: queryField valid`, isFieldKey(c.queryField));
      if (c.updateField) {
        check(`${cw}: updateField valid`, isFieldKey(c.updateField) && FIELD_SPECS[c.updateField].writable);
        check(`${cw}: updateValue passes validation`,
          validateFieldWrite(c.updateField, c.updateValue, c.updateValue === "IN_REVIEW" ? "REJECTED" : "IN_REVIEW").ok);
      }
      if (c.href) check(`${cw}: href is an internal path`, c.href.startsWith("/"));
    }
  }
}
check("dialog: fleet-only choice hidden without fleet",
  !visibleChoices(STATES["begin"].choices, { fleet: false }).some((c) => c.requires === "fleet"));
check("dialog: fleet-only choice shown with fleet",
  visibleChoices(STATES["begin"].choices, { fleet: true }).some((c) => c.requires === "fleet"));

// ---- field validation & security properties --------------------------------------
check("isFieldKey rejects prototype keys", !isFieldKey("toString") && !isFieldKey("__proto__") && !isFieldKey("constructor"));
check("isFieldKey rejects SQL-ish input", !isFieldKey("salary; DROP TABLE users"));
check("read-only field can't be written", !validateFieldWrite("plan", "enterprise").ok && !validateFieldWrite("backends", 99).ok);
check("threshold ok", validateFieldWrite("alert_threshold", "0.95").ok);
check("threshold rounds", (() => { const r = validateFieldWrite("alert_threshold", "0.9504"); return r.ok && r.value === 0.95; })());
check("threshold low rejected", !validateFieldWrite("alert_threshold", "0.2").ok);
check("threshold high rejected", !validateFieldWrite("alert_threshold", "1.5").ok);
check("threshold junk rejected", !validateFieldWrite("alert_threshold", "abc").ok && !validateFieldWrite("alert_threshold", "").ok);
check("email ok + lowercased", (() => { const r = validateFieldWrite("alert_email", " Ops@Lab.Example "); return r.ok && r.value === "ops@lab.example"; })());
check("email bad rejected", !validateFieldWrite("alert_email", "not-an-email").ok);
check("email too long rejected", !validateFieldWrite("alert_email", "a".repeat(250) + "@x.io").ok);
check("pilot: user can't self-approve", !validateFieldWrite("pilot_status", "APPROVED", "IN_REVIEW").ok);
check("pilot: user can't self-reject/approve from none", !validateFieldWrite("pilot_status", "APPROVED", "NOT_REQUESTED").ok);
check("pilot: none -> in review", validateFieldWrite("pilot_status", "IN_REVIEW", "NOT_REQUESTED").ok);
check("pilot: rejected -> in review (reapply)", validateFieldWrite("pilot_status", "IN_REVIEW", "REJECTED").ok);
check("pilot: in review -> withdrawn", validateFieldWrite("pilot_status", "NOT_REQUESTED", "IN_REVIEW").ok);
check("pilot: approved is locked", !validateFieldWrite("pilot_status", "NOT_REQUESTED", "APPROVED").ok);
check("format: every key produces text", (Object.keys(FIELD_SPECS) as (keyof typeof FIELD_SPECS)[]).every((k) => formatFieldReply(k, null).length > 0));

// ---- forms ---------------------------------------------------------------------------
const goodPilot = { organisation: "Acme Lab", vendor: "IBM Quantum", fleet_size: "1 backend", start_date: "2027-01-15", details: "Watch T1/T2 drift on our 27-qubit device." };
check("form: valid pilot accepted", validateFormSubmission("pilot_request", goodPilot).ok);
check("form: missing required rejected", !validateFormSubmission("pilot_request", { ...goodPilot, organisation: "" }).ok);
check("form: bad dropdown rejected", !validateFormSubmission("pilot_request", { ...goodPilot, vendor: "EvilCorp" }).ok);
check("form: bad date rejected", !validateFormSubmission("pilot_request", { ...goodPilot, start_date: "tomorrow" }).ok);
check("form: impossible date rejected", !validateFormSubmission("pilot_request", { ...goodPilot, start_date: "2027-13-45" }).ok);
check("form: over-long rejected", !validateFormSubmission("pilot_request", { ...goodPilot, details: "x".repeat(1001) }).ok);
check("form: non-object rejected", !validateFormSubmission("pilot_request", "hello").ok && !validateFormSubmission("pilot_request", null).ok && !validateFormSubmission("pilot_request", []).ok);
check("form: extra keys dropped", (() => { const r = validateFormSubmission("pilot_request", { ...goodPilot, isAdmin: "true" }); return r.ok && !("isAdmin" in r.data); })());
check("form: non-string values rejected", !validateFormSubmission("pilot_request", { ...goodPilot, organisation: { $ne: "" } }).ok);
check("form: ticket ok", validateFormSubmission("support_ticket", { subject: "q17 drifting", severity: "High", backend: "IBM Quantum", observed_at: "2026-09-28", details: "Fidelity fell overnight." }).ok);
check("form: isFormId rejects junk", !isFormId("constructor") && !isFormId("nope"));
check("form: every dropdown has options", Object.values(FORMS).every((f) => f.fields.every((x) => x.input_type !== "dropdown" || (x.values?.length ?? 0) > 0)));

// ---- rate limiter ----------------------------------------------------------------------
_resetRateLimitForTests();
const t0 = 1_000_000;
check("rate: first 3 pass", [0, 1, 2].every((i) => rateLimit("k", 3, 60_000, t0 + i).ok));
check("rate: 4th blocked", !rateLimit("k", 3, 60_000, t0 + 3).ok);
check("rate: retryAfter sane", rateLimit("k", 3, 60_000, t0 + 4).retryAfterSec > 0);
check("rate: other key unaffected", rateLimit("other", 3, 60_000, t0 + 5).ok);
check("rate: window slides", rateLimit("k", 3, 60_000, t0 + 60_001).ok);

console.log(`${passed} checks passed, ${failures.length} failed`);
if (failures.length) {
  for (const f of failures) console.log("  FAIL: " + f);
  process.exit(1);
}
