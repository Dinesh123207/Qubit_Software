# QuantumOps — Next.js + MongoDB rebuild

This replaces the earlier plain-HTML scaffold's frontend and web backend.
The Python FastAPI service from that scaffold is **not replaced** — it's
kept as a small internal service for the one thing Node can't do natively
(talk to IBM Quantum), and this app proxies to it. See "Why keep the Python
service" below.

## Stack (final, matches what was discussed in chat)

| Layer | Choice | Why |
|---|---|---|
| Framework | **Next.js 15, App Router** | Standard for production React in 2026 — Server Components by default, Server Actions for form mutations instead of hand-rolled API boilerplate |
| Language | TypeScript | Default for production Next.js codebases |
| Database | **MongoDB + Mongoose** | The "M" in MERN, as asked for. Cached-connection pattern in `lib/db.ts` (standard fix for serverless/hot-reload connection exhaustion) |
| Auth | Custom JWT (`jose`) + httpOnly cookies, `bcryptjs` for password hashing | See "Auth: a deliberate choice" below |
| Styling | Tailwind CSS | Industry default; theme tokens in `tailwind.config.ts` carry over the exact brand colors from the earlier static site |
| Charts | Recharts | Idiomatic React charting (declarative, no manual `chart.update()` calls) |
| Telemetry source | Proxies to the Python FastAPI service | No official IBM Quantum SDK for Node — see below |
| AI assistant | OpenAI (`gpt-4o-mini`) via a Next.js Route Handler, rule-based FAQ fallback if no key set | See "AI assistant" below |
| Deployment | Vercel (app) + MongoDB Atlas (db) | Native fit for Next.js; zero local install for either |

## AI assistant — adapted from your uploaded reference project

You uploaded a govt-employee chatbot project (dialog-tree + OpenAI + voice
input + typing animation). The code itself wasn't reusable as-is (React 18
class components, Node 16, hardcoded `localhost` URLs, and — worth flagging
directly since it's a real security issue — **the OpenAI key lived in a
plaintext `server/key.txt` file**, no env var, no `.gitignore` entry for it).

What got carried over is the *pattern*, rebuilt properly:
- `components/ChatWidget.tsx` — floating assistant site-wide
  (`components/GlobalChatWidget.tsx` hides it on `/dashboard`), voice input
  via the browser's native Web Speech API (no extra dependency, same
  approach as the reference project), a hand-rolled typing effect (no
  `react-type-animation` dependency needed for it)
- `app/api/chat/route.ts` — the backend. **The API key is read from
  `process.env.OPENAI_API_KEY`**, never written to disk or committed
- On `/dashboard`, the *same* `ChatWidget` component is reused in
  `mode="embedded"` with the live fleet snapshot passed in as `context` —
  so it can answer "why is q17 flagged?" using real current data, not just
  static FAQ. This is the one genuinely new capability, not just a port.
- If `OPENAI_API_KEY` isn't set, `app/api/chat/route.ts` falls back to a
  small keyword-matched FAQ responder — same "never hard-fail, degrade and
  say so" principle used everywhere else in this app.

## Chatbot — full feature set

Everything below was added on top of the first version (floating widget +
LLM fallback). All server-side, all session-verified, all rate-limited.

- **Dialog tree** (`lib/chatDialog.ts`) — menu-driven flows for pilot request
  status/reapply/withdraw, plan & usage, alert settings, and a support-ticket
  flow, branching on logged-in vs guest and (on the dashboard) whether a
  fleet exists. `scripts/test-chat.ts` walks every state in both variants and
  fails the build if any target is missing, any dropdown/date/queryField is
  invalid, or any menu is a dead end.
- **In-chat forms** (`lib/chatForms.ts`, `components/chat/DynamicChatForm.tsx`)
  — Pilot request and Report an issue, defined once and validated identically
  on the client (via the shared spec) and the server (`app/api/chat/form`) —
  a request can't be forged by skipping the UI.
- **Per-user account data** (`lib/chatFieldSpecs.ts`, `lib/chatFields.ts`,
  `app/api/chat/field`) — plan, connected backends, pilot status, alert
  threshold and alert email, readable/writable from chat. `userId` always
  comes from the verified session, never the request body; the field key is
  checked against a whitelist (`isFieldKey`, using `hasOwnProperty` so
  `"toString"`/`"__proto__"` can't slip through); pilot-status transitions
  are a small state machine (a user can request or withdraw, never
  self-approve); the threshold and email are range/format-validated before
  they touch the database.
- **Live fleet Q&A** (`lib/telemetry.ts`) — the dashboard's embedded panel
  can answer "why is q17 flagged" using the *real* current snapshot, fetched
  server-side from the Python service (or its mock fallback) — never a JSON
  blob the browser sent, which the model could otherwise be tricked into
  treating as instructions.
- **FAQ engine** (`lib/faq.ts`, `lib/faqData.ts`) — TF-IDF + cosine
  similarity over ~30 QuantumOps-specific entries, blended with a
  vocabulary-coverage score so short queries ("hi", "pricing") still match.
  Answers are honest about the product's actual stage (see the comment at
  the top of `faqData.ts`) — a support bot that overclaims is worse than
  none. Runs in-process; the reference project's separate Flask +
  sentence-transformers service (and its threshold-check bug —
  `similarities[best_match_index >= 0.9]`, indexing an array with a
  boolean, which never actually filtered anything) isn't needed.
- **Rate limiting** (`lib/rateLimit.ts`) — the reference project's
  `/api/chat` was an open, unauthenticated proxy straight to OpenAI with a
  **client-chosen model name**. Every chat-related route here is capped
  per-user (or per-IP, signed out) — 20 messages/min for chat, 30 field
  reads/writes, 10 form submissions, 40 autocomplete calls — and the model
  is fixed server-side.
- **Prompt-injection guard** — the system prompt explicitly tells the model
  to treat fleet data as untrusted data, not instructions, and to ignore any
  in-message attempt to override its scope or reveal the prompt. Not a
  perfect defense (nothing fully is), but a real, cheap mitigation the
  reference project had none of.
- **UX extras** (`components/chat/`) — voice input (Web Speech API) and
  read-aloud (`speechSynthesis`), a skip-ahead typing effect
  (`TypedText.tsx`, no dependency), local-then-AI autocomplete (Tab to
  accept), thumbs up/down feedback stored in Mongo
  (`ChatFeedback`/`app/api/chat/feedback`), copy-message, export transcript,
  new-chat, and auto-linkified `/paths` and URLs in assistant replies
  (`Linkified.tsx`). History persists per-identity in `sessionStorage`
  (clears when the tab closes) and resets on login/logout so it never leaks
  across users on a shared machine.
- **Dashboard integration** — the qubit grid, drifting count, and alert
  colours now follow *your own* fidelity threshold (settable from chat),
  not a hardcoded 0.94 — change it in chat, see it reflected live.
  `app/api/telemetry/fleet` itself is now session-verified (it was
  previously reachable by anyone who knew the URL, even though the
  dashboard *page* was protected).

### Testing

```bash
npm run test:chat
```
492 checks, no server/DB required: FAQ matching accuracy, every dialog state
reachable and non-dead-ending in both logged-in/guest variants, field
read-only/range/format/state-machine validation (including the
prototype-pollution and privilege-escalation cases the reference project was
open to), form schema validation, and rate-limiter behavior.

### What's simulated vs real

- **Real:** FAQ matching, dialog tree, field read/write validation and
  persistence (once `MONGODB_URI` is set), form validation and storage,
  rate limiting, voice input/output, typing effect, autocomplete, feedback
  storage.
- **Needs `OPENAI_API_KEY`:** free-text questions outside the ~30-entry FAQ,
  and natural-language fleet summaries (a fixed-template summary is used
  otherwise — see `summarizeFleet()` in `lib/telemetry.ts`).
- **Needs the Python service running:** live IBM Quantum calibration data
  in fleet answers (mock data is used otherwise, and every fleet answer says
  which one you're getting).

## Nav fix

`components/Nav.tsx` is now an async Server Component that calls
`getSession()` directly — it shows "Log in / Get early access" when
signed out, and your name + "Dashboard" + "Log out" when signed in, on
every page, with no client-side flash. This was a real gap before (the
nav never reflected login state at all).

## Why keep the Python service

Node has no official IBM Quantum SDK — `qiskit-ibm-runtime` is Python-only.
Re-implementing that auth flow by hand against IBM's undocumented internal
REST endpoints was a worse bet than reusing code that's already written,
already tested, and already has real error-handling (the fallback-to-mock
behavior from the earlier scaffold). `app/api/telemetry/fleet/route.ts`
proxies to it and only falls back to an in-Node mock if that service isn't
reachable — same "never hard-fail, degrade and say so" principle as before.

This is a normal, real pattern (a small Python microservice for SDK-specific
work behind a Node/Next.js app), not a compromise — most "pure Node" rewrites
of anything touching scientific-Python SDKs end up here anyway.

## Auth: a deliberate choice, not a shortcut

Current best practice for new Next.js projects is an established library
(Auth.js v5, Better Auth, Clerk). This app uses a small hand-written
JWT layer instead — `lib/auth.ts` — because:
- It's fully verifiable by hand (no OAuth provider config, no adapter setup)
  without ever running `npm install`, which mattered for building this correctly
  the first time.
- A disclosed vulnerability (CVE-2025-29927) showed that relying on Next.js
  middleware *alone* for session checks is bypassable (a spoofed
  `x-middleware-subrequest` header skips it). This app's `middleware.ts`
  does the first-pass redirect, but **every protected page also
  re-verifies the session server-side** (see `getSession()` in
  `lib/auth.ts`, called in `app/dashboard/page.tsx`) — defense in depth,
  not just the one layer.

**Before this handles real users:** swap to Auth.js v5 once you need OAuth
(Google/GitHub login) or want session revocation — this custom layer has
neither. It's fine for the pilot stage.

## Setup

1. **Database — MongoDB Atlas (recommended, zero local install):**
   Free account at https://www.mongodb.com/cloud/atlas/register → create an
   M0 (free) cluster → Connect → Drivers → copy the connection string.
   (Local alternative: install MongoDB Community Server, or
   `docker run -p 27017:27017 mongo` if you end up installing Docker.)

2. **Environment:**
   ```bash
   cp .env.example .env.local
   ```
   Fill in `MONGODB_URI` and generate a `JWT_SECRET`:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```

3. **Install and run:**
   ```bash
   npm install
   npm run dev
   ```
   Open http://localhost:3000

4. **(Optional) Seed a test account** instead of using `/register`:
   ```bash
   npm run seed
   ```
   Creates `test@quantumops.dev` / `password123`.

5. **(Optional) Real quantum data:** start the Python service from the
   earlier scaffold (`uvicorn app.main:app --reload --port 8000` from its
   `backend/` folder) — the dashboard will pick it up automatically. Without
   it running, the dashboard shows mock data and says so in the banner.

6. **(Optional) Smarter chat assistant:** add `OPENAI_API_KEY` to
   `.env.local` (see the comment there for where to get one). Without it,
   the chat widget still works, using rule-based FAQ answers instead.

## Pages

| Route | What it is |
|---|---|
| `/` | Landing |
| `/product` | Feature detail |
| `/pricing` | 3-tier pricing |
| `/about` | Founder story |
| `/contact` | Real form → MongoDB |
| `/signup` | Early-access waitlist → MongoDB |
| `/register` | Full account creation (bcrypt-hashed password) |
| `/login` | Sets an httpOnly JWT session cookie |
| `/dashboard` | **Protected** — live telemetry, polls every 2s |

## Deploying

- **App → Vercel:** `vercel` CLI or connect the GitHub repo in the Vercel
  dashboard. Set `MONGODB_URI`, `JWT_SECRET`, and `PYTHON_TELEMETRY_URL`
  (pointing at wherever the Python service ends up hosted — see that
  scaffold's own `DEPLOY.md`) as environment variables there.
- **Database → MongoDB Atlas:** already cloud-hosted from setup step 1,
  nothing further to deploy.

## What I could not verify

I don't have network access in this environment to run `npm install` /
`npm run dev` / `next build` myself — everything here was written by hand
and checked with `tsc` for syntax and type errors (all clean), but **not**
run end-to-end. Report the exact first error you hit and I'll fix it —
same as the Python backend earlier.
