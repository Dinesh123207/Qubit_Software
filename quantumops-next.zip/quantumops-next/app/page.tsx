import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import QuantumLattice from "@/components/QuantumLattice";

const features = [
  { title: "Qubit health analytics", desc: "Per-qubit T1/T2, readout fidelity and gate error tracked against long-run baselines.", tag: "calibration" },
  { title: "Decoder latency waterfall", desc: "Syndrome-to-correction timing broken down by stage.", tag: "real-time" },
  { title: "Logical error-rate alerts", desc: "Thresholds on the metric that matters downstream, with syndrome history attached.", tag: "alerting" },
  { title: "Multi-vendor abstraction", desc: "IBM, IonQ and Quantinuum metrics normalised into one schema.", tag: "fleet" },
];

export default function HomePage() {
  return (
    <>
      <Nav active="/" />
      <main>
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-14 items-center py-16 md:py-20">
          <div>
            <h1 className="font-display font-medium text-4xl md:text-5xl leading-tight max-w-[14ch]">
              See inside the decoder <em className="not-italic" style={{ color: "var(--gold)" }}>before</em> the error does.
            </h1>
            <p className="mt-5 text-lg max-w-[46ch]" style={{ color: "var(--text-muted)" }}>
              QuantumOps is the operational monitoring layer for quantum error correction — real-time qubit health, decoder latency and calibration drift, surfaced the way SIEM tooling surfaces a security incident.
            </p>
            <div className="flex gap-3 mt-8 flex-wrap">
              <Link href="/signup" className="btn btn-primary">Request early access</Link>
              <Link href="/product" className="btn btn-ghost">See the product</Link>
            </div>
          </div>
          <QuantumLattice />
        </div>

        <div className="max-w-6xl mx-auto px-6"><hr style={{ borderColor: "var(--border)" }} /></div>

        <section className="max-w-6xl mx-auto px-6 py-14">
          <h2 className="font-display font-medium text-2xl mb-2">What it watches</h2>
          <p style={{ color: "var(--text-muted)" }} className="mb-2">Four signals, one console.</p>
          <div>
            {features.map((f, i) => (
              <div
                key={f.title}
                className="grid md:grid-cols-[220px_1fr_auto] gap-6 items-center py-6"
                style={{ borderTop: "1px solid var(--border)", borderBottom: i === features.length - 1 ? "1px solid var(--border)" : undefined }}
              >
                <h3 className="font-display font-medium text-lg">{f.title}</h3>
                <p style={{ color: "var(--text-muted)" }} className="text-sm max-w-[44ch]">{f.desc}</p>
                <span className="font-mono text-xs px-2.5 py-1 rounded justify-self-start md:justify-self-end whitespace-nowrap" style={{ color: "var(--blue)", background: "var(--blue-soft)" }}>{f.tag}</span>
              </div>
            ))}
          </div>
        </section>

        <div className="max-w-6xl mx-auto px-6 pb-20">
          <div className="rounded-lg p-10 md:p-12 flex justify-between items-center gap-7 flex-wrap" style={{ background: "var(--surface)", border: "1px solid var(--gold)" }}>
            <h2 className="font-display font-medium text-2xl max-w-[20ch]">Get early access before your next pilot goes live.</h2>
            <Link href="/signup" className="btn btn-primary">Request early access</Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
