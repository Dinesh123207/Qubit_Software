import type { Metadata } from "next";
import type { ReactNode } from "react";
import GlobalChatWidget from "@/components/GlobalChatWidget";
import { getSession } from "@/lib/auth";
import "./globals.css";

export const metadata: Metadata = {
  title: "QuantumOps — Operational visibility for quantum error correction",
  description:
    "Real-time qubit health, decoder latency and calibration drift monitoring for quantum error correction fleets.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,500&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-body">
        {children}
        <GlobalChatWidget loggedIn={!!session} userName={session?.name} />
      </body>
    </html>
  );
}
