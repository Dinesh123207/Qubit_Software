"use client";

import Link from "next/link";
import { useActionState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { submitLogin, initialFormState } from "@/lib/actions";

export default function LoginPage() {
  const [state, formAction, pending] = useActionState(submitLogin, initialFormState);

  return (
    <>
      <Nav active="/login" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>Welcome back</div>
          <h1 className="font-display font-medium text-4xl mt-3">Log in</h1>
        </div>

        <form action={formAction} className="flex flex-col gap-4 max-w-md pb-16">
          <div className="field">
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email" required />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input id="password" name="password" type="password" required />
          </div>
          {state.status === "error" && (
            <div className="text-sm px-3.5 py-2.5 rounded" style={{ background: "var(--red-soft)", color: "var(--red)", border: "1px solid var(--red)" }}>
              {state.message}
            </div>
          )}
          <button type="submit" className="btn btn-primary w-full" disabled={pending}>
            {pending ? "Logging in…" : "Log in"}
          </button>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            No account yet? <Link href="/register" style={{ color: "var(--gold)" }}>Register</Link>.
          </p>
        </form>
      </main>
      <Footer />
    </>
  );
}
