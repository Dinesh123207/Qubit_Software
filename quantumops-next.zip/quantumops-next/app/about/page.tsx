import Nav from "@/components/Nav";
import Footer from "@/components/Footer";

const fit = [
  ["SOC / SIEM monitoring", "Real-time qubit health & alert design"],
  ["Cybersecurity analyst, live production systems", "DevSecOps built into the pipeline from day one"],
  ["DevOps instincts", "Fleet-wide observability across vendors, not a single dashboard"],
];

export default function AboutPage() {
  return (
    <>
      <Nav active="/about" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>About</div>
          <h1 className="font-display font-medium text-4xl mt-3 max-w-[16ch]">Why this founder, why this product</h1>
          <p className="mt-4 text-lg max-w-[52ch]" style={{ color: "var(--text-muted)" }}>
            QuantumOps started from a simple observation: the instincts that make someone good at watching a security operations center are the same instincts a quantum facility needs — and almost nobody&apos;s building for that overlap yet.
          </p>
        </div>

        <section className="mb-14">
          {fit.map(([from, to]) => (
            <div key={from} className="grid md:grid-cols-[1fr_auto_1fr] gap-4 items-center mb-3.5">
              <div className="card !py-4 text-sm">{from}</div>
              <div className="text-center font-semibold hidden md:block" style={{ color: "var(--gold)" }}>→</div>
              <div className="card !py-4 text-sm">{to}</div>
            </div>
          ))}
        </section>

        <section className="pb-16">
          <hr className="mb-8" style={{ borderColor: "var(--border)" }} />
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="font-display font-medium text-xl">The founder</h2>
              <p className="mt-3 text-sm" style={{ color: "var(--text-muted)" }}>
                Dinesh is a cybersecurity analyst based in Jaipur, India, building QuantumOps alongside a full-time security role. The product&apos;s thesis is grounded in current QEC systems research, not a hardware vendor&apos;s roadmap — see the product page for the papers it&apos;s built on.
              </p>
            </div>
            <div>
              <h2 className="font-display font-medium text-xl">Why now</h2>
              <p className="mt-3 text-sm" style={{ color: "var(--text-muted)" }}>
                2028 is the industry-consensus deadline for quantum error correction moving from lab demonstrations to production deployments. The tooling for operating those systems day-to-day hasn&apos;t caught up — that gap is the whole company.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
