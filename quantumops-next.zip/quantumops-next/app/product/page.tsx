import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";

const features = [
  { title: "Qubit health analytics", desc: "Per-qubit T1/T2, readout fidelity and gate error, tracked against long-run baselines and clustered so drift surfaces before it degrades a job — not after a paper's results don't reproduce." },
  { title: "Decoder latency waterfall", desc: "Syndrome-to-correction timing broken down stage by stage, so a tail-latency spike traces back to the exact hop that caused it — not just \"somewhere in the pipeline.\"" },
  { title: "Logical error-rate alerts", desc: "Thresholds on the metric that actually matters downstream of the code, with the syndrome history that led there attached directly to the alert." },
  { title: "Multi-vendor abstraction", desc: "IBM, IonQ and Quantinuum metrics normalised into one schema. A facility running more than one backend gets one dashboard, not three logins." },
];

const steps = [
  { title: "1. Point it at your backend", desc: "An IBM Quantum, IonQ or Quantinuum API credential — read-only calibration access, no circuits required." },
  { title: "2. It polls calibration data", desc: "T1/T2, readout fidelity, and (once wired to a QEC run) decoder latency and logical error rate." },
  { title: "3. You get alerted, not paged blind", desc: "Threshold-based alerts carry the syndrome history that caused them — context, not just a number." },
];

export default function ProductPage() {
  return (
    <>
      <Nav active="/product" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>Product</div>
          <h1 className="font-display font-medium text-4xl mt-3 max-w-[16ch]">One console for a fleet that used to need four tabs</h1>
          <p className="mt-4 text-lg max-w-[52ch]" style={{ color: "var(--text-muted)" }}>
            QuantumOps sits between your quantum hardware and your operators — normalising IBM, IonQ and Quantinuum telemetry into one schema, and turning it into alerts an on-call engineer can act on.
          </p>
        </div>

        <div className="card !p-0 overflow-hidden mb-14">
          <div className="flex justify-between px-5 py-3.5 font-mono text-xs" style={{ borderBottom: "1px solid var(--border)", color: "var(--text-muted)" }}>
            <span>fleet / distance-5 surface code / qpu-07</span>
            <span style={{ color: "var(--blue)" }}>● live</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4">
            {[
              { label: "Logical error rate", val: "1.8e-4", color: "var(--blue)" },
              { label: "Decoder latency p99", val: "640ns", color: "var(--gold)" },
              { label: "Mean T1", val: "94.2μs", color: "var(--blue)" },
              { label: "Drifting qubits", val: "3", color: "var(--red)" },
            ].map((m, i) => (
              <div key={m.label} className="px-5 py-5" style={{ borderRight: i < 3 ? "1px solid var(--border)" : undefined }}>
                <div className="text-xs" style={{ color: "var(--text-muted)" }}>{m.label}</div>
                <div className="font-mono text-2xl mt-2" style={{ color: m.color }}>{m.val}</div>
              </div>
            ))}
          </div>
        </div>

        <section className="grid md:grid-cols-2 gap-4 mb-14">
          {features.map((f) => (
            <div key={f.title} className="card">
              <h3 className="font-display font-medium text-lg">{f.title}</h3>
              <p className="mt-2.5 text-sm" style={{ color: "var(--text-muted)" }}>{f.desc}</p>
            </div>
          ))}
        </section>

        <section className="mb-14">
          <hr className="mb-9" style={{ borderColor: "var(--border)" }} />
          <h2 className="font-display font-medium text-2xl mb-5">How it connects</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {steps.map((s) => (
              <div key={s.title} className="card">
                <h3 className="text-base font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm" style={{ color: "var(--text-muted)" }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="pb-16">
          <div className="card flex justify-between items-center gap-5 flex-wrap" style={{ borderColor: "var(--gold)" }}>
            <div>
              <h3 className="font-display font-medium text-lg">Want to see it on your own fleet?</h3>
              <p className="mt-1 text-sm" style={{ color: "var(--text-muted)" }}>Free pilots for one lighthouse facility per quarter.</p>
            </div>
            <Link href="/signup" className="btn btn-primary">Request early access</Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
