import Link from "next/link";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";

const tiers = [
  {
    name: "Pilot", price: "Free", period: "/ 90 days", featured: false,
    items: ["One QPU or backend", "Qubit health + calibration drift monitoring", "Email alerts", "Direct line to the founder"],
    cta: "Request a pilot", href: "/signup",
  },
  {
    name: "Facility", price: "$15k", period: "/ month", featured: true,
    items: ["Up to 5 backends, multi-vendor", "Full decoder latency + logical error-rate monitoring", "Slack/PagerDuty alert routing", "Calibration history & audit export"],
    cta: "Get early access", href: "/signup",
  },
  {
    name: "National lab / Enterprise", price: "Custom", period: "", featured: false,
    items: ["Unlimited backends, multi-site", "SSO, audit-grade access controls", "On-prem / air-gapped deployment option", "Dedicated onboarding"],
    cta: "Talk to us", href: "/contact",
  },
];

export default function PricingPage() {
  return (
    <>
      <Nav active="/pricing" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>Pricing</div>
          <h1 className="font-display font-medium text-4xl mt-3 max-w-[18ch]">Priced for a pilot, not a procurement cycle</h1>
          <p className="mt-4 text-lg max-w-[52ch]" style={{ color: "var(--text-muted)" }}>
            Early-access terms while QuantumOps is in pilot — nothing here is final until we&apos;ve validated it on a real fleet with you.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-4 pb-6">
          {tiers.map((t) => (
            <div
              key={t.name}
              className="rounded-lg p-7 flex flex-col"
              style={{
                background: t.featured ? "linear-gradient(180deg, var(--gold-soft), var(--surface) 60%)" : "var(--surface)",
                border: `1px solid ${t.featured ? "var(--gold)" : "var(--border)"}`,
              }}
            >
              <div className="font-display font-medium text-lg">{t.name}</div>
              <div className="font-mono text-3xl mt-3">
                {t.price}
                {t.period && <span className="text-sm font-body ml-1" style={{ color: "var(--text-muted)" }}>{t.period}</span>}
              </div>
              <ul className="mt-5 flex flex-col gap-2.5 flex-1">
                {t.items.map((it) => (
                  <li key={it} className="text-sm pl-4 relative" style={{ color: "var(--text-muted)" }}>
                    <span className="absolute left-0" style={{ color: "var(--gold)" }}>—</span>
                    {it}
                  </li>
                ))}
              </ul>
              <Link href={t.href} className={`btn ${t.featured ? "btn-primary" : "btn-ghost"} mt-6 w-full`}>{t.cta}</Link>
            </div>
          ))}
        </div>
        <p className="mt-4 text-sm pb-16" style={{ color: "var(--text-muted)" }}>
          Building for a national lab or a shared-infrastructure facility?{" "}
          <Link href="/contact" style={{ color: "var(--gold)" }} className="no-underline">Get in touch</Link>{" "}
          — pricing for multi-tenant, shared-QPU setups is worked out case by case.
        </p>
      </main>
      <Footer />
    </>
  );
}
