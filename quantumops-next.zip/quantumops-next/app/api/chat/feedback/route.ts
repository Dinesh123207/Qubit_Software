import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { dbConnect } from "@/lib/db";
import { ChatFeedback } from "@/models/Chat";
import { rateLimit, clientKey } from "@/lib/rateLimit";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const session = await getSession();
  const rl = rateLimit(`fb:${clientKey(req, session?.userId)}`, 20, 60_000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  let body: { rating?: unknown; userMessage?: unknown; assistantMessage?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }
  if (body.rating !== "up" && body.rating !== "down") return NextResponse.json({ error: "Invalid rating." }, { status: 400 });

  const clip = (v: unknown) => (typeof v === "string" ? v.slice(0, 500) : undefined);
  try {
    await dbConnect();
    await ChatFeedback.create({
      userId: session?.userId,
      rating: body.rating,
      userMessage: clip(body.userMessage),
      assistantMessage: clip(body.assistantMessage),
    });
    return NextResponse.json({ ok: true });
  } catch {
    // Feedback is best-effort; never surface a DB problem to the widget.
    return NextResponse.json({ ok: false });
  }
}
