import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { rateLimit, clientKey } from "@/lib/rateLimit";
import { formatFieldReply, isFieldKey, validateFieldWrite } from "@/lib/chatFieldSpecs";
import { getFieldValue, setFieldValue } from "@/lib/chatFields";

export const runtime = "nodejs";

// Replaces the reference project's /api/fetch + /api/update, which trusted a
// client-supplied userId AND column name. Here: userId comes from the signed
// session, the key must be whitelisted, and writes are validated.
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "login_required" }, { status: 401 });

  const rl = rateLimit(`field:${clientKey(req, session.userId)}`, 30, 60_000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } });

  let body: { action?: unknown; key?: unknown; value?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }
  if (!isFieldKey(body.key)) return NextResponse.json({ error: "Unknown field." }, { status: 400 });
  const key = body.key;

  try {
    if (body.action === "get") {
      const data = await getFieldValue(session.userId, key);
      return NextResponse.json({ data });
    }
    if (body.action === "set") {
      const current = await getFieldValue(session.userId, key);
      const check = validateFieldWrite(key, body.value, current);
      if (check.ok === false) return NextResponse.json({ error: check.error }, { status: 422 });
      await setFieldValue(session.userId, key, check.value);
      return NextResponse.json({ data: check.value, message: `Done. ${formatFieldReply(key, check.value)}` });
    }
    return NextResponse.json({ error: "Unknown action." }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Couldn't reach the database right now." }, { status: 503 });
  }
}
