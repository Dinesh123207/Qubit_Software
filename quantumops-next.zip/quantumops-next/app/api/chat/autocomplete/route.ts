import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { clientKey, rateLimit } from "@/lib/rateLimit";

export const runtime = "nodejs";

// Port of the reference project's "autocomplete as you type" (Tab to accept).
// The client tries local FAQ typeahead first (free, instant); this route only
// runs for prefixes the FAQ can't complete, and only if an API key is set.
export async function POST(req: Request) {
  const session = await getSession();
  const rl = rateLimit(`ac:${clientKey(req, session?.userId)}`, 40, 60_000);
  if (!rl.ok) return NextResponse.json({ completion: null }, { status: 429 });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return NextResponse.json({ completion: null });

  let body: { prefix?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ completion: null }, { status: 400 });
  }
  const prefix = typeof body.prefix === "string" ? body.prefix.slice(0, 120) : "";
  if (prefix.trim().length < 8) return NextResponse.json({ completion: null });

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "Complete the user's partially typed question to a support assistant for QuantumOps (quantum error-correction fleet monitoring). Reply with ONLY the words that continue it, at most 8 words. If unsure, reply DENIED.",
          },
          { role: "user", content: prefix },
        ],
        temperature: 0.2,
        max_tokens: 20,
      }),
      signal: AbortSignal.timeout(4000),
    });
    if (!res.ok) return NextResponse.json({ completion: null });
    const data = await res.json();
    const raw: string = (data.choices?.[0]?.message?.content ?? "").trim();
    if (!raw || /denied/i.test(raw) || raw.length > 80) return NextResponse.json({ completion: null });
    return NextResponse.json({ completion: raw });
  } catch {
    return NextResponse.json({ completion: null });
  }
}
