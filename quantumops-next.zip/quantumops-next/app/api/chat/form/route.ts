import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { dbConnect } from "@/lib/db";
import { ChatFormSubmission } from "@/models/Chat";
import { rateLimit, clientKey } from "@/lib/rateLimit";
import { isFormId, validateFormSubmission } from "@/lib/chatForms";
import { getFieldValue, setFieldValue } from "@/lib/chatFields";

export const runtime = "nodejs";

// Replaces the reference project's /api/upload, which stored whatever JSON the
// client sent, for whoever sent it.
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "login_required" }, { status: 401 });

  const rl = rateLimit(`form:${clientKey(req, session.userId)}`, 10, 60_000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } });

  let body: { formId?: unknown; data?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }
  if (!isFormId(body.formId)) return NextResponse.json({ error: "Unknown form." }, { status: 400 });

  const check = validateFormSubmission(body.formId, body.data);
  if (check.ok === false) return NextResponse.json({ error: check.error }, { status: 422 });

  try {
    await dbConnect();

    if (body.formId === "pilot_request") {
      const status = String((await getFieldValue(session.userId, "pilot_status")) ?? "NOT_REQUESTED");
      if (status !== "NOT_REQUESTED" && status !== "REJECTED") {
        return NextResponse.json({ error: "You already have an active or approved pilot request." }, { status: 409 });
      }
    }

    const doc = await ChatFormSubmission.create({ userId: session.userId, formId: body.formId, data: check.data });

    if (body.formId === "pilot_request") {
      await setFieldValue(session.userId, "pilot_status", "IN_REVIEW");
      return NextResponse.json({ ok: true, message: "Thanks — your pilot request is submitted and now in review. We'll email you when there's an update." });
    }
    const ref = String(doc._id).slice(-6).toUpperCase();
    return NextResponse.json({ ok: true, message: `Thanks — ticket #${ref} is logged. The founder reads every one.` });
  } catch {
    return NextResponse.json({ error: "Couldn't reach the database right now." }, { status: 503 });
  }
}
