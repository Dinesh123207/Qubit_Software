import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getFieldValue } from "@/lib/chatFields";
import { applyThreshold, getFleetSnapshot } from "@/lib/telemetry";

export const runtime = "nodejs";

// Was previously open to anyone who knew the URL; the dashboard *page* was
// protected but its data API wasn't. Every protected read re-verifies the
// session itself (see the CVE-2025-29927 note in lib/auth.ts).
export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "login_required" }, { status: 401 });

  const snap = await getFleetSnapshot();

  // Use this user's own fidelity threshold (changeable from the chat), so the
  // dashboard's "drifting" count and colours follow their settings.
  let threshold = 0.94;
  try {
    const v = await getFieldValue(session.userId, "alert_threshold");
    if (typeof v === "number") threshold = v;
  } catch {
    // DB down -> default threshold; telemetry still renders.
  }
  return NextResponse.json(applyThreshold(snap, threshold));
}
