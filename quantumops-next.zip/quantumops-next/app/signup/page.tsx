"use client";

import Link from "next/link";
import { useActionState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { submitSignup, initialFormState } from "@/lib/actions";

export default function SignupPage() {
  const [state, formAction, pending] = useActionState(submitSignup, initialFormState);

  return (
    <>
      <Nav active="/signup" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>Early access</div>
          <h1 className="font-display font-medium text-4xl mt-3">Get on the list</h1>
          <p className="mt-4 text-lg max-w-[52ch]" style={{ color: "var(--text-muted)" }}>
            No commitment — just tell us who you are, and we&apos;ll reach out when there&apos;s a pilot slot open for your kind of fleet.
          </p>
        </div>

        <form action={formAction} className="flex flex-col gap-4 max-w-md pb-16">
          <div className="field">
            <label htmlFor="email">Work email</label>
            <input id="email" name="email" type="email" required />
          </div>
          <div className="field">
            <label htmlFor="role">I&apos;m closest to…</label>
            <select id="role" name="role" defaultValue="enterprise">
              <option value="enterprise">An enterprise quantum team</option>
              <option value="lab">A national or government lab</option>
              <option value="university">A research university</option>
              <option value="other">Something else</option>
            </select>
          </div>
          {state.status !== "idle" && (
            <div
              className="text-sm px-3.5 py-2.5 rounded"
              style={{
                background: state.status === "success" ? "var(--blue-soft)" : "var(--red-soft)",
                color: state.status === "success" ? "var(--blue)" : "var(--red)",
                border: `1px solid ${state.status === "success" ? "var(--blue)" : "var(--red)"}`,
              }}
            >
              {state.message}
            </div>
          )}
          <button type="submit" className="btn btn-primary w-full" disabled={pending}>
            {pending ? "Joining…" : "Join the list"}
          </button>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            Already have an account? <Link href="/login" style={{ color: "var(--gold)" }}>Log in</Link>. Want a full account with dashboard access now?{" "}
            <Link href="/register" style={{ color: "var(--gold)" }}>Register</Link> instead.
          </p>
        </form>
      </main>
      <Footer />
    </>
  );
}
