"use client";

import { useActionState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { submitContact, initialFormState } from "@/lib/actions";

export default function ContactPage() {
  const [state, formAction, pending] = useActionState(submitContact, initialFormState);

  return (
    <>
      <Nav active="/contact" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>Contact</div>
          <h1 className="font-display font-medium text-4xl mt-3">Talk to us</h1>
          <p className="mt-4 text-lg max-w-[52ch]" style={{ color: "var(--text-muted)" }}>
            Questions about a pilot, enterprise pricing, or the research behind the product — this goes straight to the founder, not a queue.
          </p>
        </div>

        <form action={formAction} className="flex flex-col gap-4 max-w-md pb-16">
          <div className="field">
            <label htmlFor="name">Name</label>
            <input id="name" name="name" type="text" required />
          </div>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email" required />
          </div>
          <div className="field">
            <label htmlFor="message">Message</label>
            <textarea id="message" name="message" required placeholder="What are you trying to solve?" />
          </div>
          {state.status !== "idle" && (
            <div
              className="text-sm px-3.5 py-2.5 rounded"
              style={{
                background: state.status === "success" ? "var(--blue-soft)" : "var(--red-soft)",
                color: state.status === "success" ? "var(--blue)" : "var(--red)",
                border: `1px solid ${state.status === "success" ? "var(--blue)" : "var(--red)"}`,
              }}
            >
              {state.message}
            </div>
          )}
          <button type="submit" className="btn btn-primary w-full" disabled={pending}>
            {pending ? "Sending…" : "Send message"}
          </button>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            You can also email <a href="mailto:hello@quantumops.dev" style={{ color: "var(--gold)" }}>hello@quantumops.dev</a> directly.
          </p>
        </form>
      </main>
      <Footer />
    </>
  );
}
