import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import DashboardClient from "@/components/DashboardClient";

// Re-checking the session here (in addition to middleware.ts) is deliberate:
// CVE-2025-29927 showed middleware-only auth in Next.js can be bypassed by a
// spoofed header, so every protected Server Component re-verifies the JWT
// itself rather than trusting middleware alone.
export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  return <DashboardClient userName={session.name} />;
}
