"use client";

import Link from "next/link";
import { useActionState } from "react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { submitRegister, initialFormState } from "@/lib/actions";

export default function RegisterPage() {
  const [state, formAction, pending] = useActionState(submitRegister, initialFormState);

  return (
    <>
      <Nav active="/register" />
      <main className="max-w-6xl mx-auto px-6">
        <div className="py-16">
          <div className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--gold)" }}>Create account</div>
          <h1 className="font-display font-medium text-4xl mt-3">Register</h1>
          <p className="mt-4 text-lg max-w-[52ch]" style={{ color: "var(--text-muted)" }}>
            A full account — for when you&apos;re ready to actually connect a backend and use the dashboard, not just join the waitlist.
          </p>
        </div>

        <form action={formAction} className="flex flex-col gap-4 max-w-md pb-16">
          <div className="field">
            <label htmlFor="name">Full name</label>
            <input id="name" name="name" type="text" required />
          </div>
          <div className="field">
            <label htmlFor="email">Work email</label>
            <input id="email" name="email" type="email" required />
          </div>
          <div className="field">
            <label htmlFor="company">Company / lab (optional)</label>
            <input id="company" name="company" type="text" />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input id="password" name="password" type="password" minLength={8} required />
          </div>
          {state.status === "error" && (
            <div className="text-sm px-3.5 py-2.5 rounded" style={{ background: "var(--red-soft)", color: "var(--red)", border: "1px solid var(--red)" }}>
              {state.message}
            </div>
          )}
          <button type="submit" className="btn btn-primary w-full" disabled={pending}>
            {pending ? "Creating account…" : "Create account"}
          </button>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            Already registered? <Link href="/login" style={{ color: "var(--gold)" }}>Log in</Link>. Just want updates?{" "}
            <Link href="/signup" style={{ color: "var(--gold)" }}>Join the waitlist</Link> instead.
          </p>
        </form>
      </main>
      <Footer />
    </>
  );
}
