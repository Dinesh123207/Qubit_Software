import { FAQ, type FaqEntry } from "./faqData";

const STOP = new Set([
  "a", "an", "the", "is", "are", "was", "were", "be", "been", "am", "to", "of", "and", "or", "in", "on", "for",
  "with", "do", "does", "did", "it", "its", "this", "that", "these", "those", "can", "could", "would", "should",
  "will", "you", "your", "we", "our", "us", "what", "whats", "s", "how", "which", "when", "where", "why",
  "please", "tell", "about", "there", "any", "get", "i", "me", "im", "ive", "some", "at", "as", "by", "from",
]);

function stem(t: string): string {
  let s = t;
  if (s.length > 3 && s.endsWith("s") && !s.endsWith("ss")) s = s.slice(0, -1);
  if (s.length > 5 && s.endsWith("ing")) s = s.slice(0, -3);
  else if (s.length > 4 && s.endsWith("ed")) s = s.slice(0, -2);
  if (s.length > 4 && s.endsWith("e")) s = s.slice(0, -1);
  return s;
}

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t && !STOP.has(t))
    .map(stem);
}

type Doc = { entry: FaqEntry; tf: Map<string, number> };

function termFreq(tokens: string[]): Map<string, number> {
  const m = new Map<string, number>();
  for (const t of tokens) m.set(t, (m.get(t) ?? 0) + 1);
  return m;
}

const docs: Doc[] = FAQ.map((entry) => ({
  entry,
  // The question counts double relative to the keyword list.
  tf: termFreq([...tokenize(entry.question), ...tokenize(entry.question), ...tokenize((entry.keywords ?? []).join(" "))]),
}));

const df = new Map<string, number>();
for (const d of docs) for (const t of d.tf.keys()) df.set(t, (df.get(t) ?? 0) + 1);
const N = docs.length;
const idf = (t: string) => Math.log((N + 1) / ((df.get(t) ?? 0) + 1)) + 1;

function vector(tf: Map<string, number>): Map<string, number> {
  const v = new Map<string, number>();
  for (const [t, c] of tf) v.set(t, c * idf(t));
  return v;
}
function norm(v: Map<string, number>): number {
  let s = 0;
  for (const x of v.values()) s += x * x;
  return Math.sqrt(s);
}

const docVectors = docs.map((d) => {
  const v = vector(d.tf);
  return { entry: d.entry, v, n: norm(v) };
});

export type FaqMatch = { entry: FaqEntry; score: number };

export function bestMatch(query: string, threshold = 0.3): FaqMatch | null {
  const qTokens = tokenize(query);
  if (qTokens.length === 0) return null;
  const qv = vector(termFreq(qTokens));
  const qn = norm(qv);
  if (qn === 0) return null;

  let best: FaqMatch | null = null;
  for (const d of docVectors) {
    let dot = 0;
    for (const [t, w] of qv) {
      const dw = d.v.get(t);
      if (dw) dot += w * dw;
    }
    if (dot === 0) continue;
    const cosine = dot / (qn * d.n);
    // Short queries ("hi", "pricing") score low on pure cosine against a long
    // entry, so blend in how much of the query's (idf-weighted) vocabulary the
    // entry actually covers.
    let covered = 0;
    let total = 0;
    for (const [t, w] of qv) {
      total += w;
      if (d.v.has(t)) covered += w;
    }
    const score = 0.7 * cosine + 0.3 * (total ? covered / total : 0);
    if (!best || score > best.score) best = { entry: d.entry, score };
  }
  return best && best.score >= threshold ? best : null;
}
