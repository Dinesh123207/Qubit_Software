"use server";

import { z } from "zod";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { dbConnect } from "@/lib/db";
import { User } from "@/models/User";
import { ContactMessage, EarlyAccessSignup } from "@/models/ContactMessage";
import { createSessionToken, SESSION_COOKIE_NAME } from "@/lib/auth";

export type FormState = { status: "idle" | "success" | "error"; message: string };
const idle: FormState = { status: "idle", message: "" };

const contactSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Enter a valid email"),
  message: z.string().min(1, "Message can't be empty"),
});

export async function submitContact(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = contactSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    message: formData.get("message"),
  });
  if (!parsed.success) {
    return { status: "error", message: parsed.error.issues[0].message };
  }
  try {
    await dbConnect();
    await ContactMessage.create(parsed.data);
    return { status: "success", message: "Thanks — message received. We'll get back to you soon." };
  } catch (err) {
    return { status: "error", message: dbErrorMessage(err) };
  }
}

const signupSchema = z.object({
  email: z.string().email("Enter a valid email"),
  role: z.string().optional(),
});

export async function submitSignup(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = signupSchema.safeParse({
    email: formData.get("email"),
    role: formData.get("role"),
  });
  if (!parsed.success) {
    return { status: "error", message: parsed.error.issues[0].message };
  }
  try {
    await dbConnect();
    const existing = await EarlyAccessSignup.findOne({ email: parsed.data.email });
    if (existing) {
      return { status: "error", message: "This email is already on the list." };
    }
    await EarlyAccessSignup.create(parsed.data);
    return { status: "success", message: "You're on the list — we'll be in touch." };
  } catch (err) {
    return { status: "error", message: dbErrorMessage(err) };
  }
}

const registerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Enter a valid email"),
  company: z.string().optional(),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export async function submitRegister(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = registerSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    company: formData.get("company") || undefined,
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { status: "error", message: parsed.error.issues[0].message };
  }
  try {
    await dbConnect();
    const existing = await User.findOne({ email: parsed.data.email });
    if (existing) {
      return { status: "error", message: "An account with this email already exists." };
    }
    const hashedPassword = await bcrypt.hash(parsed.data.password, 10);
    await User.create({ ...parsed.data, hashedPassword });
  } catch (err) {
    return { status: "error", message: dbErrorMessage(err) };
  }
  redirect("/login?registered=1");
}

const loginSchema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(1, "Password is required"),
});

export async function submitLogin(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = loginSchema.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { status: "error", message: parsed.error.issues[0].message };
  }
  let userId = "";
  let name = "";
  try {
    await dbConnect();
    const user = await User.findOne({ email: parsed.data.email });
    if (!user || !(await bcrypt.compare(parsed.data.password, user.hashedPassword))) {
      return { status: "error", message: "Invalid email or password." };
    }
    userId = String(user._id);
    name = user.name;
  } catch (err) {
    return { status: "error", message: dbErrorMessage(err) };
  }

  const token = await createSessionToken({ userId, email: parsed.data.email, name });
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
  redirect("/dashboard");
}

export async function logout(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE_NAME);
  redirect("/login");
}

function dbErrorMessage(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  return `Can't reach the database right now (${msg}). Is MongoDB running and MONGODB_URI set?`;
}

export const initialFormState = idle;
