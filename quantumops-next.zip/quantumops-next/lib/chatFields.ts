import { dbConnect } from "@/lib/db";
import { User } from "@/models/User";
import { FIELD_SPECS, type FieldKey } from "@/lib/chatFieldSpecs";

// The only place chat touches user data. `userId` always comes from the
// verified session (never from the request body) and `key` is a whitelisted
// FieldKey, so neither can be used for injection or cross-user access.

export async function getFieldValue(userId: string, key: FieldKey): Promise<unknown> {
  await dbConnect();
  const path = FIELD_SPECS[key].path;
  const user = await User.findById(userId).select(path).lean();
  if (!user) return null;
  return (user as Record<string, unknown>)[path] ?? null;
}

export async function setFieldValue(userId: string, key: FieldKey, value: string | number): Promise<void> {
  await dbConnect();
  const path = FIELD_SPECS[key].path;
  await User.updateOne({ _id: userId }, { $set: { [path]: value } });
}
