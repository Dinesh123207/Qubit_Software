import { formatFieldReply, type FieldKey } from "./chatFieldSpecs";
import type { FormId } from "./chatForms";

// Same shape of idea as the reference project's DialogMessage / DialogChoice:
//   choice.queryField      -> read a per-user value, reply with replyMessageFunc
//   choice.updateField     -> write a per-user value (validated server-side)
//   state.form             -> render an in-chat form, then autoTransitionState
//   state.awaitInput       -> next typed message is the value (the reference's
//                             "$userInput" mechanism), validated server-side
// Two sentinel ids keep one tree for both audiences:
//   "home" -> begin / begin_guest      "more" -> more_user / more_guest

export type DialogContext = { name?: string };

export type DialogChoice = {
  id: string;
  display: string;
  requires?: "fleet";                 // only shown where a live fleet exists (dashboard)
  href?: string;                      // navigate instead of transitioning
  sendPrompt?: string;                // hand the prompt to the assistant (FAQ -> LLM)
  queryField?: FieldKey;
  replyMessageFunc?: (data: unknown) => string;
  updateField?: FieldKey;
  updateValue?: string;
  next?: string | ((data: unknown) => string);
};

export type DialogState = {
  id: string;
  message: string | ((ctx: DialogContext) => string);
  choices: DialogChoice[];
  choicesFrom?: string;               // reuse another state's choices (menus)
  autoTransitionState?: string;
  form?: FormId;
  awaitInput?: { field: FieldKey; next: string };
};

const firstName = (ctx: DialogContext) => (ctx.name ? ctx.name.split(" ")[0] : "");

const pilotReply = (data: unknown) => formatFieldReply("pilot_status", data);
const pilotNext = (data: unknown): string => {
  switch (String(data)) {
    case "REJECTED": return "reapply";
    case "IN_REVIEW": return "in_review";
    case "APPROVED": return "more";
    default: return "request_pilot";
  }
};

const list: DialogState[] = [
  { id: "root_user", message: (c) => (firstName(c) ? `Hi ${firstName(c)}.` : "Hi there."), choices: [], autoTransitionState: "begin" },
  { id: "root_guest", message: "Hi there.", choices: [], autoTransitionState: "begin_guest" },

  // ---- main menus ---------------------------------------------------------
  {
    id: "begin", message: "How can I help you today?",
    choices: [
      { id: "pilot_status", display: "Pilot request status", queryField: "pilot_status", replyMessageFunc: pilotReply, next: pilotNext },
      { id: "usage", display: "My plan & usage", next: "usage" },
      { id: "alerts", display: "Alert settings", next: "alerts" },
      { id: "fleet", display: "Summarise my fleet", requires: "fleet", sendPrompt: "Give me a short summary of my fleet's current health and anything I should look at." },
      { id: "ticket", display: "Report an issue", next: "ticket_form" },
      { id: "founder", display: "Contact the founder", next: "contact_founder" },
    ],
  },
  {
    id: "begin_guest", message: "How can I help you today?",
    choices: [
      { id: "monitors", display: "What does it monitor?", sendPrompt: "What does QuantumOps monitor?" },
      { id: "pricing", display: "Pricing", sendPrompt: "How much does QuantumOps cost?" },
      { id: "pilot", display: "Request a pilot", next: "guest_pilot" },
      { id: "founder", display: "Contact the founder", next: "contact_founder" },
    ],
  },
  { id: "more_user", message: "Anything else I can help with?", choices: [], choicesFrom: "begin" },
  { id: "more_guest", message: "Anything else I can help with?", choices: [], choicesFrom: "begin_guest" },

  // ---- guests -------------------------------------------------------------
  {
    id: "guest_pilot",
    message: "Pilots are tied to an account so we can track your request. Register to request one, or join the waitlist and we'll reach out.",
    choices: [
      { id: "register", display: "Register an account", href: "/register" },
      { id: "login", display: "I already have an account", href: "/login" },
      { id: "waitlist", display: "Join the waitlist", href: "/signup" },
      { id: "back", display: "Back", next: "home" },
    ],
  },

  // ---- pilot request lifecycle (the reference project's leave-application flow)
  {
    id: "reapply", message: "Would you like to re-apply?",
    choices: [
      { id: "yes", display: "Yes", updateField: "pilot_status", updateValue: "IN_REVIEW", next: "reapplied" },
      { id: "no", display: "No", next: "home" },
    ],
  },
  { id: "reapplied", message: "Your pilot request is back in review. We'll email you when there's an update.", choices: [], autoTransitionState: "more" },
  {
    id: "in_review", message: "What would you like to do?",
    choices: [
      { id: "withdraw", display: "Withdraw my request", updateField: "pilot_status", updateValue: "NOT_REQUESTED", next: "withdrawn" },
      { id: "founder", display: "Contact the founder", next: "contact_founder" },
      { id: "back", display: "Back", next: "home" },
    ],
  },
  { id: "withdrawn", message: "Your request has been withdrawn.", choices: [], autoTransitionState: "more" },
  {
    id: "request_pilot", message: "You don't have a pilot request yet. Would you like to request one?",
    choices: [
      { id: "yes", display: "Yes", next: "pilot_form" },
      { id: "no", display: "No", next: "home" },
    ],
  },
  { id: "pilot_form", message: "Pilot request", choices: [], form: "pilot_request", autoTransitionState: "more" },

  // ---- plan & usage -------------------------------------------------------
  {
    id: "usage", message: "What would you like to see?",
    choices: [
      { id: "plan", display: "My plan", queryField: "plan", next: "more" },
      { id: "backends", display: "Connected backends", queryField: "backends", next: "more" },
      { id: "back", display: "Back", next: "home" },
    ],
  },

  // ---- alert settings (read + write, incl. free-text input states) --------
  {
    id: "alerts", message: "Alert settings — what would you like to do?",
    choices: [
      { id: "view_threshold", display: "View fidelity threshold", queryField: "alert_threshold", next: "alerts" },
      { id: "set_threshold", display: "Change fidelity threshold", next: "set_threshold" },
      { id: "view_email", display: "View alert email", queryField: "alert_email", next: "alerts" },
      { id: "set_email", display: "Change alert email", next: "set_email" },
      { id: "back", display: "Back", next: "home" },
    ],
  },
  {
    id: "set_threshold",
    message: "Type the new fidelity threshold (between 0.5 and 0.999). Qubits below it are flagged as drifting on your dashboard.",
    choices: [{ id: "cancel", display: "Cancel", next: "alerts" }],
    awaitInput: { field: "alert_threshold", next: "alerts" },
  },
  {
    id: "set_email",
    message: "Type the email address alerts should go to.",
    choices: [{ id: "cancel", display: "Cancel", next: "alerts" }],
    awaitInput: { field: "alert_email", next: "alerts" },
  },

  // ---- support ticket (the reference project's grievance form) ------------
  { id: "ticket_form", message: "Report an issue", choices: [], form: "support_ticket", autoTransitionState: "more" },

  // ---- shared -------------------------------------------------------------
  {
    id: "contact_founder", message: "The fastest way is the contact form — it goes straight to the founder.",
    choices: [
      { id: "open", display: "Open the contact form", href: "/contact" },
      { id: "back", display: "Back", next: "home" },
    ],
  },
];

export const STATES: Record<string, DialogState> = Object.fromEntries(list.map((s) => [s.id, s]));

export function resolveStateId(id: string, loggedIn: boolean): string {
  if (id === "home") return loggedIn ? "begin" : "begin_guest";
  if (id === "more") return loggedIn ? "more_user" : "more_guest";
  return id;
}

export function rootState(loggedIn: boolean): string {
  return loggedIn ? "root_user" : "root_guest";
}

export function stateMessage(state: DialogState, ctx: DialogContext): string {
  return typeof state.message === "function" ? state.message(ctx) : state.message;
}

export function visibleChoices(choices: DialogChoice[], opts: { fleet: boolean }): DialogChoice[] {
  return choices.filter((c) => (c.requires === "fleet" ? opts.fleet : true));
}

export function nextOf(choice: DialogChoice, data: unknown): string {
  if (typeof choice.next === "function") return choice.next(data);
  return choice.next ?? "home";
}
