import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "dev-only-insecure-secret-change-me"
);
const COOKIE_NAME = "quantumops_session";
const SESSION_DURATION = "7d";

export type SessionPayload = {
  userId: string;
  email: string;
  name: string;
};

export async function createSessionToken(payload: SessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(SESSION_DURATION)
    .sign(SECRET);
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return payload as unknown as SessionPayload;
  } catch {
    // Expired, malformed, or wrong-secret token -- always treat as "no session",
    // never throw past this point.
    return null;
  }
}

// Server Components / Route Handlers call this directly rather than trusting
// middleware alone -- CVE-2025-29927 showed middleware-only session checks in
// Next.js can be bypassed by spoofing the x-middleware-subrequest header, so
// every protected read re-verifies the JWT here, in addition to middleware.ts
// redirecting unauthenticated requests away early as a first line of defense.
export async function getSession(): Promise<SessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

export const SESSION_COOKIE_NAME = COOKIE_NAME;
