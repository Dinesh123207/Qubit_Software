// Pure module (no DB, no framework imports) -- shared by the API routes and
// the dialog tree, and unit-testable with plain `tsx`.
//
// The reference project let the *client* choose which DB column to read or
// write (`SELECT ${column} ...`, `UPDATE ... SET ${column} = ?`) and what value
// to write -- SQL injection plus any user being able to set their own status
// to APPROVED. Here the client only ever names a key from this whitelist, and
// every write goes through validateFieldWrite().

export type FieldKey = "pilot_status" | "plan" | "backends" | "alert_threshold" | "alert_email";
export type PilotStatus = "NOT_REQUESTED" | "IN_REVIEW" | "APPROVED" | "REJECTED";

type Spec = { path: string; label: string; writable: boolean };

export const FIELD_SPECS: Record<FieldKey, Spec> = {
  pilot_status: { path: "pilotStatus", label: "pilot status", writable: true },
  plan: { path: "plan", label: "plan", writable: false },
  backends: { path: "backendsConnected", label: "connected backends", writable: false },
  alert_threshold: { path: "alertFidelityThreshold", label: "fidelity alert threshold", writable: true },
  alert_email: { path: "alertEmail", label: "alert email", writable: true },
};

export function isFieldKey(k: unknown): k is FieldKey {
  // hasOwnProperty, not `in` -- "toString" in {} is true via the prototype chain.
  return typeof k === "string" && Object.prototype.hasOwnProperty.call(FIELD_SPECS, k);
}

export type WriteResult = { ok: true; value: string | number } | { ok: false; error: string };

export function validateFieldWrite(key: FieldKey, raw: unknown, current?: unknown): WriteResult {
  const spec = FIELD_SPECS[key];
  if (!spec.writable) return { ok: false, error: `Your ${spec.label} can't be changed from chat.` };

  switch (key) {
    case "alert_threshold": {
      const n = typeof raw === "number" ? raw : Number(String(raw ?? "").trim());
      if (!Number.isFinite(n) || n < 0.5 || n > 0.999) {
        return { ok: false, error: "Enter a number between 0.5 and 0.999 (for example 0.94)." };
      }
      return { ok: true, value: Math.round(n * 1000) / 1000 };
    }
    case "alert_email": {
      const s = String(raw ?? "").trim().toLowerCase();
      if (s.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) {
        return { ok: false, error: "That doesn't look like a valid email address." };
      }
      return { ok: true, value: s };
    }
    case "pilot_status": {
      // Users may only move between "no request" and "in review". APPROVED /
      // REJECTED are set by a human on the admin side, never from chat.
      const next = String(raw ?? "");
      const cur = String(current ?? "NOT_REQUESTED");
      if (next === "IN_REVIEW" && (cur === "NOT_REQUESTED" || cur === "REJECTED")) return { ok: true, value: next };
      if (next === "NOT_REQUESTED" && cur === "IN_REVIEW") return { ok: true, value: next };
      return { ok: false, error: "That status change isn't allowed from chat." };
    }
    default:
      return { ok: false, error: "Unsupported field." };
  }
}

export function formatFieldReply(key: FieldKey, value: unknown): string {
  switch (key) {
    case "pilot_status":
      switch (String(value)) {
        case "IN_REVIEW": return "Your pilot request is currently in review.";
        case "APPROVED": return "Your pilot request has been approved — we'll email you onboarding details.";
        case "REJECTED": return "Your pilot request wasn't accepted this time.";
        default: return "You haven't requested a pilot yet.";
      }
    case "plan":
      return `You're on the ${value ?? "pilot"} plan.`;
    case "backends": {
      const n = Number(value ?? 0);
      return n === 1 ? "You have 1 backend connected." : `You have ${n} backends connected.`;
    }
    case "alert_threshold":
      return `Your fidelity alert threshold is ${value ?? 0.94} — qubits below it are flagged as drifting.`;
    case "alert_email":
      return value ? `Alerts go to ${value}.` : "You haven't set an alert email yet.";
  }
}
