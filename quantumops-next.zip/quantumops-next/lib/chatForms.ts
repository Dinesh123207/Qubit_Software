// Pure module. Same field types the reference project's DynamicForm supported
// (text / big_text / dropdown / date), plus server-side validation so a form
// can't be submitted with values the UI would never have offered.

export type FormId = "pilot_request" | "support_ticket";

export type FormFieldDef = {
  name: string;
  label: string;
  input_type: "text" | "big_text" | "dropdown" | "date";
  required: boolean;
  values?: string[];
  maxLength?: number;
};

export type FormDef = { id: FormId; title: string; fields: FormFieldDef[] };

export const FORMS: Record<FormId, FormDef> = {
  pilot_request: {
    id: "pilot_request",
    title: "Pilot request",
    fields: [
      { name: "organisation", label: "Organisation / lab", input_type: "text", required: true, maxLength: 120 },
      { name: "vendor", label: "Primary hardware vendor", input_type: "dropdown", required: true, values: ["IBM Quantum", "IonQ", "Quantinuum", "Multiple / other"] },
      { name: "fleet_size", label: "Fleet size", input_type: "dropdown", required: true, values: ["1 backend", "2–5 backends", "6+ backends"] },
      { name: "start_date", label: "Ideal start date", input_type: "date", required: true },
      { name: "details", label: "What do you want to monitor?", input_type: "big_text", required: true, maxLength: 1000 },
    ],
  },
  support_ticket: {
    id: "support_ticket",
    title: "Report an issue",
    fields: [
      { name: "subject", label: "Subject", input_type: "text", required: true, maxLength: 120 },
      { name: "severity", label: "Severity", input_type: "dropdown", required: true, values: ["Low", "Medium", "High"] },
      { name: "backend", label: "Affected backend", input_type: "dropdown", required: true, values: ["IBM Quantum", "IonQ", "Quantinuum", "Not backend-specific"] },
      { name: "observed_at", label: "When did you notice it?", input_type: "date", required: true },
      { name: "details", label: "Details", input_type: "big_text", required: true, maxLength: 2000 },
    ],
  },
};

export function isFormId(v: unknown): v is FormId {
  return typeof v === "string" && Object.prototype.hasOwnProperty.call(FORMS, v);
}

export type FormValidation = { ok: true; data: Record<string, string> } | { ok: false; error: string };

export function validateFormSubmission(id: FormId, raw: unknown): FormValidation {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return { ok: false, error: "Invalid form data." };
  const input = raw as Record<string, unknown>;
  const out: Record<string, string> = {};

  for (const f of FORMS[id].fields) {
    const v = typeof input[f.name] === "string" ? (input[f.name] as string).trim() : "";
    if (!v) {
      if (f.required) return { ok: false, error: `“${f.label}” is required.` };
      continue;
    }
    const max = f.maxLength ?? 200;
    if (v.length > max) return { ok: false, error: `“${f.label}” must be at most ${max} characters.` };
    if (f.input_type === "dropdown" && !(f.values ?? []).includes(v)) {
      return { ok: false, error: `“${f.label}” has an invalid option.` };
    }
    if (f.input_type === "date") {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(new Date(v + "T00:00:00Z").getTime())) {
        return { ok: false, error: `“${f.label}” must be a valid date.` };
      }
    }
    out[f.name] = v; // unknown extra keys in `raw` are dropped on purpose
  }
  return { ok: true, data: out };
}
