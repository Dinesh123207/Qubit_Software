// Fleet telemetry, shared by the dashboard's polling route and the chat
// assistant. The chat builds its fleet context HERE, on the server, instead of
// trusting a JSON blob sent by the browser -- the client can't feed the model
// fake telemetry (or injected instructions) through that path.

export type QubitState = { t1: number; fidelity: number };

export type FleetSnapshot = {
  timestamp: number;
  data_source: { mode: string; detail: string };
  qubits: Record<string, QubitState>;
  decoder_latency_p99_ns: number;
  logical_error_rate: number;
  drifting_qubits: string[];
  alert_threshold?: number;
};

// The Python FastAPI service is where the real Qiskit / IBM Quantum
// integration lives (Node has no official IBM Quantum SDK).
const PYTHON_SERVICE_URL = process.env.PYTHON_TELEMETRY_URL || "http://localhost:8000/telemetry/fleet";

const mockState: Record<string, QubitState> = {};
for (let i = 0; i < 20; i++) {
  mockState[`q${i}`] = { t1: 60 + Math.random() * 60, fidelity: 0.97 + Math.random() * 0.025 };
}
let mockLatency = 500;
let mockErrorRate = 1.8e-4;

function walk(v: number, lo: number, hi: number, step: number) {
  v += (Math.random() - 0.5) * 2 * step;
  return Math.max(lo, Math.min(hi, v));
}

function mockSnapshot(): FleetSnapshot {
  for (const q of Object.values(mockState)) {
    q.t1 = walk(q.t1, 40, 140, 2.5);
    q.fidelity = walk(q.fidelity, 0.9, 0.999, 0.003);
  }
  mockLatency = walk(mockLatency, 400, 750, 40);
  mockErrorRate = walk(mockErrorRate, 1.2e-4, 2.4e-4, 0.2e-4);
  return {
    timestamp: Date.now() / 1000,
    data_source: { mode: "mock (Node, Python service unreachable)", detail: PYTHON_SERVICE_URL },
    qubits: { ...mockState },
    decoder_latency_p99_ns: mockLatency,
    logical_error_rate: mockErrorRate,
    drifting_qubits: [],
  };
}

export async function getFleetSnapshot(): Promise<FleetSnapshot> {
  try {
    const res = await fetch(PYTHON_SERVICE_URL, { cache: "no-store", signal: AbortSignal.timeout(3000) });
    if (!res.ok) throw new Error(`Python service returned HTTP ${res.status}`);
    return (await res.json()) as FleetSnapshot;
  } catch {
    // Never hard-fail: degrade to mock data and say so in data_source.
    return mockSnapshot();
  }
}

// Recompute "drifting" against the *user's own* threshold, so changing it in
// chat is reflected on the dashboard immediately.
export function applyThreshold(snap: FleetSnapshot, threshold: number): FleetSnapshot {
  const drifting = Object.entries(snap.qubits)
    .filter(([, q]) => q.fidelity < threshold)
    .map(([id]) => id);
  return { ...snap, alert_threshold: threshold, drifting_qubits: drifting };
}

export function summarizeFleet(snap: FleetSnapshot, threshold: number): string {
  const ids = Object.keys(snap.qubits);
  const n = ids.length;
  const meanT1 = n ? ids.reduce((a, id) => a + snap.qubits[id].t1, 0) / n : 0;
  const drifting = ids
    .filter((id) => snap.qubits[id].fidelity < threshold)
    .sort((a, b) => snap.qubits[a].fidelity - snap.qubits[b].fidelity);
  const lat = snap.decoder_latency_p99_ns;

  const lines: string[] = [];
  lines.push(`Fleet snapshot (${snap.data_source.mode}): ${n} qubits, mean T1 ${meanT1.toFixed(1)}μs.`);
  lines.push(
    drifting.length
      ? `${drifting.length} qubit${drifting.length === 1 ? " is" : "s are"} below your ${threshold} fidelity threshold: ` +
          drifting.slice(0, 5).map((id) => `${id} (${snap.qubits[id].fidelity.toFixed(3)})`).join(", ") +
          (drifting.length > 5 ? ", …" : "") + "."
      : `No qubits are below your ${threshold} fidelity threshold.`
  );
  lines.push(
    `Decoder p99 latency is ${lat.toFixed(0)}ns (${lat > 700 ? "above" : "within"} the 700ns budget); logical error rate is ${snap.logical_error_rate.toExponential(2)}.`
  );
  if (snap.data_source.mode.includes("mock")) {
    lines.push("Note: this is simulated data — connect an IBM Quantum token for live calibration data.");
  }
  return lines.join(" ");
}

// Compact, size-capped JSON for the LLM prompt.
export function fleetContextJSON(snap: FleetSnapshot, threshold: number): string {
  const ids = Object.keys(snap.qubits);
  const n = ids.length;
  const drifting = ids
    .filter((id) => snap.qubits[id].fidelity < threshold)
    .sort((a, b) => snap.qubits[a].fidelity - snap.qubits[b].fidelity)
    .slice(0, 10)
    .map((id) => ({ id, fidelity: Number(snap.qubits[id].fidelity.toFixed(3)) }));
  return JSON.stringify({
    data_source: snap.data_source.mode,
    qubit_count: n,
    mean_t1_us: n ? Number((ids.reduce((a, id) => a + snap.qubits[id].t1, 0) / n).toFixed(1)) : 0,
    fidelity_alert_threshold: threshold,
    drifting_qubits: drifting,
    decoder_latency_p99_ns: Math.round(snap.decoder_latency_p99_ns),
    decoder_latency_budget_ns: 700,
    logical_error_rate: snap.logical_error_rate,
  }).slice(0, 1500);
}
