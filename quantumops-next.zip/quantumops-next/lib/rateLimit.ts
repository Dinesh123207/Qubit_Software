// In-memory sliding window. Good enough for a single Node process / a pilot;
// on serverless each instance has its own memory, so the effective limit is
// looser there. Swap the Map for Upstash Redis (or similar) before this sits
// in front of a paid LLM at real scale -- the function signature can stay.

const hits = new Map<string, number[]>();
const MAX_KEYS = 5000;

export type RateResult = { ok: boolean; remaining: number; retryAfterSec: number };

export function rateLimit(key: string, limit: number, windowMs: number, now: number = Date.now()): RateResult {
  const cutoff = now - windowMs;
  const arr = (hits.get(key) ?? []).filter((t) => t > cutoff);

  if (arr.length >= limit) {
    hits.set(key, arr);
    return { ok: false, remaining: 0, retryAfterSec: Math.max(1, Math.ceil((arr[0] + windowMs - now) / 1000)) };
  }
  arr.push(now);
  hits.set(key, arr);

  if (hits.size > MAX_KEYS) {
    // Opportunistic cleanup so the map can't grow without bound.
    for (const [k, v] of hits) {
      if (!v.some((t) => t > cutoff)) hits.delete(k);
    }
  }
  return { ok: true, remaining: limit - arr.length, retryAfterSec: 0 };
}

export function clientKey(req: Request, userId?: string): string {
  if (userId) return `u:${userId}`;
  const fwd = req.headers.get("x-forwarded-for");
  const ip = fwd ? fwd.split(",")[0].trim() : "anon";
  return `ip:${ip}`;
}

export function _resetRateLimitForTests() {
  hits.clear();
}
