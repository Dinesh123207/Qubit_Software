import Link from "next/link";
import { getSession } from "@/lib/auth";
import { logout } from "@/lib/actions";

const links = [
  { href: "/product", label: "Product" },
  { href: "/pricing", label: "Pricing" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
  { href: "/dashboard", label: "Dashboard" },
];

// Server Component (async) -- reads the session directly so the nav is
// always accurate, on every page, without a client round-trip.
export default async function Nav({ active }: { active?: string }) {
  const session = await getSession();

  return (
    <header className="sticky top-0 z-40 backdrop-blur border-b" style={{ borderColor: "var(--border)", background: "color-mix(in srgb, var(--bg) 90%, transparent)" }}>
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 px-6 py-4 flex-wrap">
        <Link href="/" className="flex items-center gap-2 font-display font-semibold text-lg no-underline" style={{ color: "var(--text)" }}>
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="2.1" fill="var(--gold)" />
            <ellipse cx="12" cy="12" rx="10" ry="4" stroke="var(--text)" strokeWidth="1.1" />
            <ellipse cx="12" cy="12" rx="10" ry="4" stroke="var(--text)" strokeWidth="1.1" transform="rotate(60 12 12)" />
            <ellipse cx="12" cy="12" rx="10" ry="4" stroke="var(--text)" strokeWidth="1.1" transform="rotate(120 12 12)" />
          </svg>
          QuantumOps
        </Link>
        <nav className="hidden md:flex gap-6 text-sm">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="no-underline"
              style={{ color: active === l.href ? "var(--gold)" : "var(--text-muted)" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex gap-2 items-center">
          {session ? (
            <>
              <span className="text-sm hidden sm:inline" style={{ color: "var(--text-muted)" }}>{session.name}</span>
              <form action={logout}>
                <button type="submit" className="btn btn-ghost">Log out</button>
              </form>
              <Link href="/dashboard" className="btn btn-primary">Dashboard</Link>
            </>
          ) : (
            <>
              <Link href="/login" className="btn btn-ghost">Log in</Link>
              <Link href="/signup" className="btn btn-primary">Get early access</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
