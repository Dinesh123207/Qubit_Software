"use client";

import { usePathname } from "next/navigation";
import ChatWidget from "@/components/ChatWidget";

// Floating assistant everywhere except /dashboard, which mounts its own
// embedded, fleet-aware instance.
export default function GlobalChatWidget({ loggedIn, userName }: { loggedIn: boolean; userName?: string }) {
  const pathname = usePathname();
  if (pathname?.startsWith("/dashboard")) return null;
  return <ChatWidget mode="floating" loggedIn={loggedIn} userName={userName} />;
}
