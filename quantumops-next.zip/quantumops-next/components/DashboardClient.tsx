"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { logout } from "@/lib/actions";
import ChatWidget from "@/components/ChatWidget";

type Qubit = { t1: number; fidelity: number };
type Snapshot = {
  timestamp: number;
  data_source: { mode: string; detail: string };
  qubits: Record<string, Qubit>;
  decoder_latency_p99_ns: number;
  logical_error_rate: number;
  drifting_qubits: string[];
  alert_threshold?: number;
};
type Alert = { id: number; text: string; sev: "err" | "warn"; time: string };
type HistPoint = { t: string; latency: number; error: number };

const POLL_MS = 2000;
const MAX_HISTORY = 24;
const MAX_ALERTS = 8;

export default function DashboardClient({ userName }: { userName: string }) {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [connected, setConnected] = useState(false);
  const [connError, setConnError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistPoint[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const seenDrift = useRef<Set<string>>(new Set());
  const alertIdRef = useRef(0);

  useEffect(() => {
    let cancelled = false;

    async function tick() {
      try {
        const res = await fetch("/api/telemetry/fleet", { cache: "no-store" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data: Snapshot = await res.json();
        if (cancelled) return;

        setSnapshot(data);
        setConnected(true);
        setConnError(null);

        setHistory((prev) => {
          const label = new Date().toTimeString().slice(3, 8);
          const next = [...prev, { t: label, latency: data.decoder_latency_p99_ns, error: data.logical_error_rate }];
          return next.length > MAX_HISTORY ? next.slice(next.length - MAX_HISTORY) : next;
        });

        const drifting = new Set(data.drifting_qubits);
        const newAlerts: Alert[] = [];
        drifting.forEach((qid) => {
          if (!seenDrift.current.has(qid)) {
            alertIdRef.current += 1;
            newAlerts.push({ id: alertIdRef.current, text: `${qid} readout fidelity dropped below threshold`, sev: "err", time: new Date().toTimeString().slice(0, 8) });
          }
        });
        seenDrift.current = drifting;
        if (data.decoder_latency_p99_ns > 700) {
          alertIdRef.current += 1;
          newAlerts.push({ id: alertIdRef.current, text: `Decoder p99 latency approaching budget (${data.decoder_latency_p99_ns.toFixed(0)}ns)`, sev: "warn", time: new Date().toTimeString().slice(0, 8) });
        }
        if (newAlerts.length) {
          setAlerts((prev) => [...newAlerts.reverse(), ...prev].slice(0, MAX_ALERTS));
        }
      } catch (err) {
        if (cancelled) return;
        setConnected(false);
        setConnError(err instanceof Error ? err.message : String(err));
      }
    }

    tick();
    const id = setInterval(tick, POLL_MS);
    return () => { cancelled = true; clearInterval(id); };
  }, []);

  const qubitIds = snapshot ? Object.keys(snapshot.qubits) : [];
  const driftCount = snapshot?.drifting_qubits.length ?? 0;
  const meanT1 = snapshot ? Object.values(snapshot.qubits).reduce((a, q) => a + q.t1, 0) / qubitIds.length : 0;

  const bannerColor = !connected ? "var(--red)" : snapshot?.data_source.mode === "real" ? "var(--blue)" : snapshot?.data_source.mode.includes("mock") ? "var(--gold)" : "var(--text-muted)";
  const bannerText = !connected
    ? `⚠ Can't reach the API — is the Next.js dev server running? (${connError ?? "connecting…"})`
    : snapshot?.data_source.mode === "real"
      ? `● Live data — connected to ${snapshot.data_source.detail}`
      : `○ ${snapshot?.data_source.mode} — ${snapshot?.data_source.detail}`;

  return (
    <div className="min-h-screen" style={{ background: "var(--bg)", color: "var(--text)" }}>
      <header className="sticky top-0 z-30 backdrop-blur border-b" style={{ borderColor: "var(--border)", background: "color-mix(in srgb, var(--bg) 90%, transparent)" }}>
        <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-3.5 flex-wrap gap-3">
          <Link href="/" className="flex items-center gap-2 font-display font-semibold no-underline" style={{ color: "var(--text)" }}>
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none"><circle cx="12" cy="12" r="2.1" fill="var(--gold)" /><ellipse cx="12" cy="12" rx="10" ry="4" stroke="var(--text)" strokeWidth="1.1" /><ellipse cx="12" cy="12" rx="10" ry="4" stroke="var(--text)" strokeWidth="1.1" transform="rotate(60 12 12)" /><ellipse cx="12" cy="12" rx="10" ry="4" stroke="var(--text)" strokeWidth="1.1" transform="rotate(120 12 12)" /></svg>
            QuantumOps
          </Link>
          <div className="flex items-center gap-4 text-sm" style={{ color: "var(--text-muted)" }}>
            <span>{userName}</span>
            <form action={logout}><button type="submit" className="btn btn-ghost !py-1.5 !px-3 text-xs">Log out</button></form>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6">
        <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-md font-mono text-sm mb-5" style={{ border: `1px solid ${bannerColor}`, color: bannerColor, background: "var(--surface)" }}>
          {bannerText}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 mb-5">
          {[
            { label: "Logical error rate", val: snapshot ? snapshot.logical_error_rate.toExponential(2) : "—", color: "var(--blue)" },
            { label: "Decoder latency (p99)", val: snapshot ? `${snapshot.decoder_latency_p99_ns.toFixed(0)}ns` : "—", color: snapshot && snapshot.decoder_latency_p99_ns > 700 ? "var(--gold)" : "var(--blue)" },
            { label: "Mean T1", val: snapshot ? `${meanT1.toFixed(1)}μs` : "—", color: "var(--blue)" },
            { label: "Drifting qubits", val: driftCount, color: driftCount > 0 ? "var(--red)" : "var(--blue)" },
          ].map((k) => (
            <div key={k.label} className="card">
              <div className="text-xs" style={{ color: "var(--text-muted)" }}>{k.label}</div>
              <div className="font-mono text-2xl mt-2" style={{ color: k.color }}>{k.val}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-[1.1fr_1.4fr] gap-4 mb-4">
          <div className="card !p-0 overflow-hidden">
            <div className="flex justify-between px-4 py-3 font-mono text-xs" style={{ borderBottom: "1px solid var(--border)", color: "var(--text-muted)" }}>
              <span>{qubitIds.length} qubits</span><span>live</span>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-5 gap-1.5">
                {qubitIds.map((id) => {
                  const f = snapshot!.qubits[id].fidelity;
                  const thr = snapshot!.alert_threshold ?? 0.94;
                  const color = f < thr ? "var(--red)" : f < thr + 0.025 ? "var(--gold)" : "var(--blue)";
                  return (
                    <div key={id} title={`${id}: ${f.toFixed(3)}`} className="aspect-square rounded flex items-center justify-center font-mono text-[0.62rem]" style={{ background: color, color: "var(--bg)" }}>
                      {id.replace("q", "")}
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-4 mt-3.5 font-mono text-xs flex-wrap" style={{ color: "var(--text-muted)" }}>
                <span><span className="inline-block w-2 h-2 rounded-sm mr-1.5" style={{ background: "var(--blue)" }} />healthy</span>
                <span><span className="inline-block w-2 h-2 rounded-sm mr-1.5" style={{ background: "var(--gold)" }} />watch</span>
                <span><span className="inline-block w-2 h-2 rounded-sm mr-1.5" style={{ background: "var(--red)" }} />drifting</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="card !p-0 overflow-hidden">
              <div className="px-4 py-3 font-mono text-xs" style={{ borderBottom: "1px solid var(--border)", color: "var(--text-muted)" }}>decoder latency p99 (ns)</div>
              <div className="p-3" style={{ height: 150 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history}>
                    <CartesianGrid stroke="var(--border)" vertical={false} />
                    <XAxis dataKey="t" tick={{ fontSize: 9, fill: "var(--text-muted)" }} />
                    <YAxis tick={{ fontSize: 9, fill: "var(--text-muted)" }} />
                    <Tooltip contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)", fontSize: 12 }} />
                    <Line type="monotone" dataKey="latency" stroke="var(--gold)" strokeWidth={2} dot={false} isAnimationActive={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="card !p-0 overflow-hidden">
              <div className="px-4 py-3 font-mono text-xs" style={{ borderBottom: "1px solid var(--border)", color: "var(--text-muted)" }}>logical error rate</div>
              <div className="p-3" style={{ height: 150 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history}>
                    <CartesianGrid stroke="var(--border)" vertical={false} />
                    <XAxis dataKey="t" tick={{ fontSize: 9, fill: "var(--text-muted)" }} />
                    <YAxis tick={{ fontSize: 9, fill: "var(--text-muted)" }} />
                    <Tooltip contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)", fontSize: 12 }} />
                    <Line type="monotone" dataKey="error" stroke="var(--blue)" strokeWidth={2} dot={false} isAnimationActive={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        <div className="card !p-0 overflow-hidden">
          <div className="flex justify-between px-4 py-3 font-mono text-xs" style={{ borderBottom: "1px solid var(--border)", color: "var(--text-muted)" }}>
            <span>alert feed</span><span>{alerts.length} events</span>
          </div>
          {alerts.length === 0 ? (
            <div className="px-4 py-6 text-sm text-center" style={{ color: "var(--text-muted)" }}>Watching fleet — alerts will appear here as thresholds are crossed.</div>
          ) : (
            <ul>
              {alerts.map((a) => (
                <li key={a.id} className="flex gap-3 items-baseline px-4 py-2.5 text-sm" style={{ borderBottom: "1px solid var(--border)" }}>
                  <span className="w-1.5 h-1.5 rounded-full flex-none mt-1" style={{ background: a.sev === "err" ? "var(--red)" : "var(--gold)" }} />
                  <span className="font-mono text-xs whitespace-nowrap" style={{ color: "var(--text-muted)" }}>{a.time}</span>
                  <span>{a.text}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="mt-4">
          <ChatWidget mode="embedded" title="Ask about this fleet" loggedIn userName={userName} fleet />
        </div>
      </main>
    </div>
  );
}
