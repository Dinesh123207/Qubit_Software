"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  STATES, nextOf, resolveStateId, rootState, stateMessage, visibleChoices,
  type DialogChoice,
} from "@/lib/chatDialog";
import { formatFieldReply, type FieldKey } from "@/lib/chatFieldSpecs";
import { FORMS, type FormId } from "@/lib/chatForms";
import { FAQ } from "@/lib/faqData";
import TypedText from "./TypedText";
import Linkified from "./Linkified";
import DynamicChatForm from "./DynamicChatForm";

type Msg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  typing?: boolean;
  error?: boolean;
  source?: string;
  rating?: "up" | "down";
};

type FieldResult = { ok: true; data: unknown; message?: string } | { ok: false; error: string };

type Props = {
  mode: "floating" | "embedded";
  title?: string;
  loggedIn: boolean;
  userName?: string;
  fleet?: boolean;
  onClose?: () => void;
};

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

async function callField(action: "get" | "set", key: FieldKey, value?: string): Promise<FieldResult> {
  try {
    const res = await fetch("/api/chat/field", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, key, value }),
    });
    const json = await res.json().catch(() => ({} as Record<string, unknown>));
    if (res.status === 401) return { ok: false, error: "Please log in first — /login" };
    if (res.status === 429) return { ok: false, error: "You're going a bit fast — try again in a moment." };
    if (!res.ok) return { ok: false, error: typeof json.error === "string" ? json.error : "Something went wrong." };
    return { ok: true, data: json.data, message: typeof json.message === "string" ? json.message : undefined };
  } catch {
    return { ok: false, error: "Couldn't reach the server." };
  }
}

// Minimal type for the non-standard Web Speech API (no @types package).
type SpeechRecognitionLike = {
  continuous: boolean; lang: string; interimResults: boolean;
  start: () => void; stop: () => void;
  onresult: ((e: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
};

export default function ChatPanel({ mode, title = "Ask QuantumOps", loggedIn, userName, fleet = false, onClose }: Props) {
  const router = useRouter();
  // sessionStorage (not localStorage): history clears when the tab closes, which
  // is the safer default for a support chat that can show account data.
  const storageKey = `qops_chat_v2_${loggedIn ? userName ?? "user" : "guest"}`;

  const [messages, setMessages] = useState<Msg[]>([]);
  const [choices, setChoices] = useState<DialogChoice[]>([]);
  const [showChoices, setShowChoices] = useState(false);
  const [activeForm, setActiveForm] = useState<FormId | null>(null);
  const [input, setInput] = useState("");
  const [suggestion, setSuggestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const stateRef = useRef("");
  const messagesRef = useRef<Msg[]>([]);
  const pendingTransition = useRef<(() => void) | null>(null);
  const initRef = useRef(false);
  const inputRef = useRef("");
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  messagesRef.current = messages;

  // ---- message helpers ------------------------------------------------------
  const appendUser = (content: string) =>
    setMessages((p) => [...p, { id: uid(), role: "user", content }]);
  const appendAssistant = (content: string, extra?: Partial<Msg>) =>
    setMessages((p) => [...p, { id: uid(), role: "assistant", content, typing: true, ...extra }]);

  // Finish any in-flight typing immediately (called when the user acts).
  const finishTyping = () => {
    pendingTransition.current = null;
    setMessages((p) => p.map((m) => (m.typing ? { ...m, typing: false } : m)));
  };

  // ---- dialog engine ----------------------------------------------------------
  const transitionTo = useCallback(
    (rawId: string) => {
      const id = resolveStateId(rawId, loggedIn);
      const st = STATES[id];
      if (!st) return;
      const source = st.choicesFrom ? STATES[resolveStateId(st.choicesFrom, loggedIn)] : st;
      stateRef.current = id;
      setChoices(visibleChoices(source.choices, { fleet }));
      setShowChoices(false);
      setActiveForm(st.form ?? null);
      appendAssistant(stateMessage(st, { name: userName }));
    },
    [loggedIn, userName, fleet]
  );

  const onTypingDone = useCallback(
    (msgId: string) => {
      setMessages((p) => p.map((m) => (m.id === msgId ? { ...m, typing: false } : m)));
      setShowChoices(true);
      const fn = pendingTransition.current;
      if (fn) {
        pendingTransition.current = null;
        fn();
        return;
      }
      const st = STATES[stateRef.current];
      if (st?.autoTransitionState && !st.form && !st.awaitInput) transitionTo(st.autoTransitionState);
    },
    [transitionTo]
  );

  // Show a reply, then continue to another state once it has finished typing.
  const replyThen = (content: string, nextId: string | null, extra?: Partial<Msg>) => {
    appendAssistant(content, extra);
    pendingTransition.current = nextId ? () => transitionTo(nextId) : null;
  };

  // ---- init / persistence -------------------------------------------------------
  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;
    let saved: Msg[] = [];
    try {
      const raw = sessionStorage.getItem(storageKey);
      const parsed: unknown = raw ? JSON.parse(raw) : [];
      if (Array.isArray(parsed)) {
        saved = parsed.slice(-50).map((m: Record<string, unknown>) => ({
          id: String(m.id ?? uid()),
          role: m.role === "user" ? ("user" as const) : ("assistant" as const),
          content: String(m.content ?? "").slice(0, 2000),
          error: Boolean(m.error),
          source: typeof m.source === "string" ? m.source : undefined,
        }));
      }
    } catch {
      /* ignore corrupt storage */
    }
    if (saved.length) {
      const home = resolveStateId("home", loggedIn);
      stateRef.current = home;
      setMessages(saved);
      setChoices(visibleChoices(STATES[home].choices, { fleet }));
      setShowChoices(true);
    } else {
      transitionTo(rootState(loggedIn));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!messages.length) return;
    try {
      sessionStorage.setItem(
        storageKey,
        JSON.stringify(messages.slice(-50).map(({ id, role, content, error, source }) => ({ id, role, content, error, source })))
      );
    } catch {
      /* storage unavailable */
    }
  }, [messages, storageKey]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, showChoices, activeForm]);

  // ---- assistant call (FAQ -> fleet -> LLM, decided server-side) -----------------
  async function askAssistant(text: string, bubble?: string) {
    const userMsg: Msg = { id: uid(), role: "user", content: bubble ?? text };
    setMessages((p) => [...p, userMsg]);
    setBusy(true);
    setShowChoices(false);
    const history = [...messagesRef.current, { ...userMsg, content: text }]
      .filter((m) => !m.error)
      .slice(-10)
      .map((m) => ({ role: m.role, content: m.content }));
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history, fleet }),
      });
      const data = await res.json().catch(() => ({} as Record<string, unknown>));
      const reply = typeof data.reply === "string" ? data.reply : "Something went wrong — please try again.";
      replyThen(reply, "more", { source: typeof data.source === "string" ? data.source : undefined, error: !res.ok && res.status !== 429 });
    } catch {
      replyThen("Couldn't reach the assistant just now — try again, or use /contact.", "more", { error: true });
    } finally {
      setBusy(false);
    }
  }

  // ---- choice buttons -----------------------------------------------------------
  async function chooseOption(c: DialogChoice) {
    if (busy) return;
    finishTyping();
    setShowChoices(false);

    if (c.sendPrompt) {
      // askAssistant adds the user bubble itself (showing the button label).
      await askAssistant(c.sendPrompt, c.display);
      return;
    }
    appendUser(c.display);

    if (c.href) {
      router.push(c.href);
      setShowChoices(true);
      return;
    }
    if (c.updateField && c.updateValue !== undefined) {
      setBusy(true);
      const r = await callField("set", c.updateField, c.updateValue);
      setBusy(false);
      if (r.ok === false) {
        replyThen(r.error, "home", { error: true });
        return;
      }
    }
    if (c.queryField) {
      setBusy(true);
      const r = await callField("get", c.queryField);
      setBusy(false);
      if (r.ok === false) {
        replyThen(r.error, "home", { error: true });
        return;
      }
      const reply = c.replyMessageFunc ? c.replyMessageFunc(r.data) : formatFieldReply(c.queryField, r.data);
      replyThen(reply, nextOf(c, r.data));
      return;
    }
    setTimeout(() => transitionTo(nextOf(c, null)), 350);
  }

  // ---- free text ----------------------------------------------------------------
  async function handleSend() {
    const text = input.trim();
    if (!text || busy) return;
    finishTyping();
    setInput("");
    setSuggestion("");

    const st = STATES[stateRef.current];
    if (st?.awaitInput && !activeForm) {
      // The typed message IS the value (the reference project's "$userInput").
      appendUser(text);
      setBusy(true);
      const r = await callField("set", st.awaitInput.field, text);
      setBusy(false);
      if (r.ok === true) replyThen(r.message ?? "Done.", st.awaitInput.next);
      else replyThen(`${r.error} Try again, or press Cancel.`, null, { error: true });
      return;
    }
    if (activeForm) setActiveForm(null); // typing abandons an open form
    await askAssistant(text);
  }

  async function submitForm(formId: FormId, data: Record<string, string>): Promise<string | null> {
    try {
      const res = await fetch("/api/chat/form", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ formId, data }),
      });
      const json = await res.json().catch(() => ({} as Record<string, unknown>));
      if (res.status === 401) return "Please log in first — /login";
      if (!res.ok) return typeof json.error === "string" ? json.error : "Something went wrong.";
      const st = STATES[stateRef.current];
      setActiveForm(null);
      replyThen(typeof json.message === "string" ? json.message : "Submitted.", st?.autoTransitionState ?? "more");
      return null;
    } catch {
      return "Couldn't reach the server.";
    }
  }

  // ---- extras: voice, speak, copy, feedback, export, reset ------------------------
  function toggleVoice() {
    const w = window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike; SpeechRecognition?: new () => SpeechRecognitionLike };
    const Ctor = w.webkitSpeechRecognition || w.SpeechRecognition;
    if (!Ctor) return;
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }
    const rec = new Ctor();
    rec.continuous = false;
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.onresult = (e) => setInput(e.results[0][0].transcript);
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    rec.start();
    recognitionRef.current = rec;
    setListening(true);
  }

  function speak(text: string) {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
  }

  async function copy(m: Msg) {
    try {
      await navigator.clipboard.writeText(m.content);
      setCopiedId(m.id);
      setTimeout(() => setCopiedId((cur) => (cur === m.id ? null : cur)), 1200);
    } catch {
      /* clipboard blocked */
    }
  }

  function rate(m: Msg, rating: "up" | "down") {
    if (m.rating) return;
    setMessages((p) => p.map((x) => (x.id === m.id ? { ...x, rating } : x)));
    const idx = messagesRef.current.findIndex((x) => x.id === m.id);
    const prevUser = [...messagesRef.current.slice(0, idx)].reverse().find((x) => x.role === "user");
    fetch("/api/chat/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rating, userMessage: prevUser?.content, assistantMessage: m.content }),
    }).catch(() => {});
  }

  function exportTranscript() {
    const text = messagesRef.current
      .map((m) => `${m.role === "user" ? "You" : "QuantumOps"}: ${m.content}`)
      .join("\n\n");
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "quantumops-chat.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  function newChat() {
    try { sessionStorage.removeItem(storageKey); } catch { /* ignore */ }
    pendingTransition.current = null;
    setMessages([]);
    setChoices([]);
    setShowChoices(false);
    setActiveForm(null);
    setInput("");
    setSuggestion("");
    transitionTo(rootState(loggedIn));
  }

  // ---- typeahead (local FAQ first, LLM only when the FAQ can't complete it) -------
  useEffect(() => {
    inputRef.current = input;
    setSuggestion("");
    const st = STATES[stateRef.current];
    if (input.trim().length < 3 || st?.awaitInput || activeForm) return;
    const lower = input.toLowerCase();
    const local = FAQ.map((f) => f.question).find((q) => q.toLowerCase().startsWith(lower) && q.length > input.length);
    if (local) {
      setSuggestion(local);
      return;
    }
    if (input.length < 8) return;
    const t = setTimeout(async () => {
      try {
        const res = await fetch("/api/chat/autocomplete", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prefix: input }),
        });
        const j = await res.json();
        if (typeof j.completion === "string" && inputRef.current === input) {
          setSuggestion(input + (input.endsWith(" ") ? "" : " ") + j.completion);
        }
      } catch {
        /* typeahead is optional */
      }
    }, 450);
    return () => clearTimeout(t);
  }, [input, activeForm]);

  const ghostSuffix =
    suggestion && suggestion.toLowerCase().startsWith(input.toLowerCase()) ? suggestion.slice(input.length) : "";
  const lastMsg = messages[messages.length - 1];
  const awaiting = Boolean(STATES[stateRef.current]?.awaitInput);

  // ---- render ---------------------------------------------------------------------
  const iconBtn = "text-xs px-1.5 py-0.5 rounded hover:opacity-80";
  return (
    <div
      className="flex flex-col rounded-lg overflow-hidden"
      style={{ background: "var(--surface)", border: "1px solid var(--border)", width: mode === "floating" ? 380 : "100%", height: mode === "floating" ? 540 : 480 }}
    >
      <div className="flex justify-between items-center px-4 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
        <span className="font-display font-medium text-sm">{title}</span>
        <div className="flex items-center gap-1" style={{ color: "var(--text-muted)" }}>
          <button onClick={newChat} aria-label="New chat" title="New chat" className={iconBtn}>↻</button>
          <button onClick={exportTranscript} aria-label="Export transcript" title="Export transcript" className={iconBtn}>⭳</button>
          {mode === "floating" && <button onClick={onClose} aria-label="Close chat" className={iconBtn}>✕</button>}
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-3" aria-live="polite">
        {messages.map((m) => (
          <div key={m.id} className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}>
            <div
              className="text-sm max-w-[88%] px-3 py-2 rounded-lg whitespace-pre-wrap"
              style={{
                background: m.role === "user" ? "var(--gold-soft)" : m.error ? "var(--red-soft)" : "var(--surface-2)",
                color: m.error ? "var(--red)" : "var(--text)",
              }}
            >
              {m.role === "assistant" && m.typing ? (
                <TypedText text={m.content} onDone={() => onTypingDone(m.id)} />
              ) : (
                <Linkified text={m.content} />
              )}
            </div>
            {m.role === "assistant" && !m.typing && (
              <div className="flex items-center gap-0.5 mt-0.5" style={{ color: "var(--text-muted)" }}>
                <button onClick={() => copy(m)} aria-label="Copy" title="Copy" className={iconBtn}>{copiedId === m.id ? "✓" : "⧉"}</button>
                <button onClick={() => speak(m.content)} aria-label="Read aloud" title="Read aloud" className={iconBtn}>🔊</button>
                {!m.error && (
                  <>
                    <button onClick={() => rate(m, "up")} aria-label="Helpful" title="Helpful" className={iconBtn} style={{ opacity: m.rating === "down" ? 0.3 : 1, color: m.rating === "up" ? "var(--blue)" : undefined }}>👍</button>
                    <button onClick={() => rate(m, "down")} aria-label="Not helpful" title="Not helpful" className={iconBtn} style={{ opacity: m.rating === "up" ? 0.3 : 1, color: m.rating === "down" ? "var(--red)" : undefined }}>👎</button>
                  </>
                )}
                {m.source === "openai" && <span className="text-[0.62rem] ml-1 font-mono">AI</span>}
              </div>
            )}
          </div>
        ))}

        {busy && <div className="text-xs" style={{ color: "var(--text-muted)" }}>Thinking…</div>}

        {activeForm && lastMsg && !lastMsg.typing && (
          <DynamicChatForm
            form={FORMS[activeForm]}
            onSubmit={(data) => submitForm(activeForm, data)}
            onCancel={() => { setActiveForm(null); setShowChoices(true); transitionTo("home"); }}
          />
        )}

        {showChoices && !activeForm && choices.length > 0 && (
          <div className="flex flex-col gap-1.5 mt-1">
            {choices.map((c) => (
              <button
                key={c.id}
                onClick={() => chooseOption(c)}
                className="text-left text-xs px-3 py-2 rounded transition-opacity hover:opacity-80"
                style={{ border: "1px solid var(--border)", color: "var(--text)" }}
              >
                {c.display}
              </button>
            ))}
          </div>
        )}
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); void handleSend(); }}
        className="flex items-center gap-2 px-3 py-2.5"
        style={{ borderTop: "1px solid var(--border)" }}
      >
        <div className="relative flex-1">
          {ghostSuffix && (
            <div className="absolute inset-0 flex items-center text-sm whitespace-pre overflow-hidden pointer-events-none" aria-hidden="true">
              <span style={{ color: "transparent" }}>{input}</span>
              <span style={{ color: "var(--text-muted)", opacity: 0.6 }}>{ghostSuffix}</span>
            </div>
          )}
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Tab" && ghostSuffix) { e.preventDefault(); setInput(suggestion); setSuggestion(""); }
              else if (e.key === "Escape") setSuggestion("");
            }}
            maxLength={500}
            placeholder={awaiting ? "Type your answer…" : "Ask a question…"}
            aria-label="Message"
            className="w-full text-sm bg-transparent outline-none relative"
            style={{ color: "var(--text)" }}
          />
        </div>
        {ghostSuffix && (
          <button type="button" onClick={() => { setInput(suggestion); setSuggestion(""); }} className="text-[0.62rem] font-mono px-1.5 py-0.5 rounded" style={{ border: "1px solid var(--border)", color: "var(--text-muted)" }} title="Accept suggestion">Tab</button>
        )}
        <button type="button" onClick={toggleVoice} aria-label="Voice input" className="text-sm px-1.5" style={{ color: listening ? "var(--red)" : "var(--text-muted)" }}>🎤</button>
        <button type="submit" className="btn btn-primary !py-1.5 !px-3 text-xs" disabled={busy}>Send</button>
      </form>
    </div>
  );
}
