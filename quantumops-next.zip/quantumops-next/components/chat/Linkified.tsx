import Link from "next/link";

// Turns site paths (/pricing) and URLs in assistant text into real links.
const PATHS = "pricing|product|about|contact|signup|register|login|dashboard";
const RE = new RegExp(`(\\/(?:${PATHS})\\b|https?:\\/\\/[^\\s)]+)`, "g");

export default function Linkified({ text }: { text: string }) {
  const parts = text.split(RE);
  return (
    <>
      {parts.map((part, i) => {
        if (i % 2 === 0) return <span key={i}>{part}</span>;
        const style = { color: "var(--gold)", textDecoration: "underline" };
        return part.startsWith("/") ? (
          <Link key={i} href={part} style={style}>{part}</Link>
        ) : (
          <a key={i} href={part} target="_blank" rel="noopener noreferrer" style={style}>{part}</a>
        );
      })}
    </>
  );
}
