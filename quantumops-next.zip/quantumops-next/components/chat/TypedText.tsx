"use client";

import { useEffect, useRef, useState } from "react";
import Linkified from "./Linkified";

// Typing effect (the reference project used react-type-animation; this needs
// no dependency). Click the text to skip ahead. onDone fires exactly once.
export default function TypedText({ text, onDone, speed = 14 }: { text: string; onDone?: () => void; speed?: number }) {
  const [n, setN] = useState(0);
  const doneRef = useRef(false);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  useEffect(() => {
    doneRef.current = false;
    setN(0);
    const id = setInterval(() => setN((v) => Math.min(text.length, v + 2)), speed);
    return () => clearInterval(id);
  }, [text, speed]);

  useEffect(() => {
    if (n >= text.length && !doneRef.current) {
      doneRef.current = true;
      onDoneRef.current?.();
    }
  }, [n, text]);

  return (
    <span onClick={() => setN(text.length)} title="Click to skip" style={{ cursor: "pointer" }}>
      <Linkified text={text.slice(0, n)} />
    </span>
  );
}
