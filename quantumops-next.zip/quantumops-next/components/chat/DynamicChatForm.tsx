"use client";

import { useState } from "react";
import type { FormDef } from "@/lib/chatForms";

// Port of the reference project's DynamicForm: renders text / big_text /
// dropdown / date fields from a definition, with native required-field checks.
// onSubmit resolves to an error message (form stays open) or null (success).
export default function DynamicChatForm({
  form,
  onSubmit,
  onCancel,
}: {
  form: FormDef;
  onSubmit: (data: Record<string, string>) => Promise<string | null>;
  onCancel: () => void;
}) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const set = (name: string, v: string) => setValues((prev) => ({ ...prev, [name]: v }));

  async function handleSubmit(e: { preventDefault: () => void }) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const err = await onSubmit(values);
    if (err) setError(err);
    setSubmitting(false);
  }

  const inputStyle = {
    width: "100%", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 5,
    padding: "7px 9px", color: "var(--text)", fontSize: "0.8rem", fontFamily: "var(--font-body)",
  } as const;

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2.5 p-3 rounded-lg" style={{ background: "var(--surface-2)", border: "1px solid var(--border)" }}>
      <div className="font-display font-medium text-sm">{form.title}</div>
      {form.fields.map((f) => (
        <label key={f.name} className="flex flex-col gap-1 text-xs" style={{ color: "var(--text-muted)" }}>
          {f.label}{f.required && " *"}
          {f.input_type === "dropdown" ? (
            <select required={f.required} value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} style={inputStyle}>
              <option value="" disabled>Select…</option>
              {(f.values ?? []).map((v) => <option key={v} value={v}>{v}</option>)}
            </select>
          ) : f.input_type === "big_text" ? (
            <textarea required={f.required} maxLength={f.maxLength} rows={3} value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} style={{ ...inputStyle, resize: "vertical" }} />
          ) : (
            <input
              required={f.required}
              maxLength={f.maxLength}
              type={f.input_type === "date" ? "date" : "text"}
              value={values[f.name] ?? ""}
              onChange={(e) => set(f.name, e.target.value)}
              style={inputStyle}
            />
          )}
        </label>
      ))}
      {error && <div className="text-xs px-2 py-1.5 rounded" style={{ background: "var(--red-soft)", color: "var(--red)", border: "1px solid var(--red)" }}>{error}</div>}
      <div className="flex gap-2 justify-end">
        <button type="button" onClick={onCancel} className="btn btn-ghost !py-1.5 !px-3 text-xs">Cancel</button>
        <button type="submit" disabled={submitting} className="btn btn-primary !py-1.5 !px-3 text-xs">{submitting ? "Submitting…" : "Submit"}</button>
      </div>
    </form>
  );
}
