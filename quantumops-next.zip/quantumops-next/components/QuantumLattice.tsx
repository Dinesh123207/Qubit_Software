"use client";

import { useEffect, useRef } from "react";

type Point = {
  x: number; y: number; data: boolean;
  err: number; targetErr: number;
  matchTo: Point | null; matchProg: number;
};

export default function QuantumLattice() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let W = 0, H = 0;
    const cols = 7, rows = 7;
    let pts: Point[] = [];

    const styleVar = (n: string) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

    function resize() {
      const rect = canvas!.getBoundingClientRect();
      W = rect.width; H = rect.height;
      canvas!.width = W * dpr; canvas!.height = H * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      pts = [];
      const padX = W * 0.14, padY = H * 0.14;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          pts.push({
            x: padX + (W - 2 * padX) * (c / (cols - 1)),
            y: padY + (H - 2 * padY) * (r / (rows - 1)),
            data: (r + c) % 2 === 0,
            err: 0, targetErr: 0, matchTo: null, matchProg: 0,
          });
        }
      }
    }
    window.addEventListener("resize", resize);
    resize();

    let lastSpawn = 0;
    function maybeSpawn(t: number) {
      if (t - lastSpawn < 900) return;
      if (Math.random() < 0.55) {
        const dataPts = pts.filter((p) => p.data && p.err === 0);
        if (dataPts.length) {
          const p = dataPts[Math.floor(Math.random() * dataPts.length)];
          p.targetErr = 1;
          const others = dataPts.filter((o) => o !== p);
          if (others.length) {
            const nearest = others.reduce<{ o: Point; d: number } | null>((best, o) => {
              const d = Math.hypot(o.x - p.x, o.y - p.y);
              return !best || d < best.d ? { o, d } : best;
            }, null);
            p.matchTo = nearest ? nearest.o : null;
            p.matchProg = 0;
          }
          lastSpawn = t;
        }
      }
    }

    let raf = 0;
    function draw(t: number) {
      const gold = styleVar("--gold") || "#D4AF6A";
      const blue = styleVar("--blue") || "#6FA8DC";
      const red = "#E2694B";
      const border = styleVar("--border") || "#262F42";

      ctx!.clearRect(0, 0, W, H);
      ctx!.strokeStyle = border;
      ctx!.lineWidth = 1;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const i = r * cols + c;
          if (c < cols - 1) { ctx!.beginPath(); ctx!.moveTo(pts[i].x, pts[i].y); ctx!.lineTo(pts[i + 1].x, pts[i + 1].y); ctx!.stroke(); }
          if (r < rows - 1) { ctx!.beginPath(); ctx!.moveTo(pts[i].x, pts[i].y); ctx!.lineTo(pts[i + cols].x, pts[i + cols].y); ctx!.stroke(); }
        }
      }
      pts.forEach((p) => {
        if (p.matchTo && p.matchProg > 0 && p.matchProg < 1) {
          const mx = p.x + (p.matchTo.x - p.x) * p.matchProg;
          const my = p.y + (p.matchTo.y - p.y) * p.matchProg;
          ctx!.strokeStyle = blue; ctx!.lineWidth = 1.6;
          ctx!.beginPath(); ctx!.moveTo(p.x, p.y); ctx!.lineTo(mx, my); ctx!.stroke();
        }
      });
      pts.forEach((p) => {
        p.err += (p.targetErr - p.err) * 0.12;
        if (!reduced) {
          if (p.targetErr === 1 && p.matchTo) {
            p.matchProg = Math.min(1, p.matchProg + 0.035);
            if (p.matchProg >= 1) { p.targetErr = 0; p.matchProg = 0; }
          }
        } else {
          p.targetErr = 0;
        }
        const radius = p.data ? 4.2 : 2.6;
        const color = p.data ? gold : blue;
        if (p.err > 0.05) { ctx!.fillStyle = red; ctx!.globalAlpha = 0.9; }
        else { ctx!.fillStyle = color; ctx!.globalAlpha = p.data ? 0.9 : 0.5; }
        ctx!.beginPath(); ctx!.arc(p.x, p.y, radius + p.err * 2.2, 0, Math.PI * 2); ctx!.fill();
        ctx!.globalAlpha = 1;
      });

      if (!reduced) { maybeSpawn(t); raf = requestAnimationFrame(draw); }
    }
    raf = requestAnimationFrame(draw);
    if (reduced) draw(0);

    return () => { window.removeEventListener("resize", resize); cancelAnimationFrame(raf); };
  }, []);

  return (
    <div className="relative aspect-square rounded-md overflow-hidden card !p-0">
      <canvas ref={canvasRef} className="w-full h-full block" aria-hidden="true" />
    </div>
  );
}
