"use client";

import { useState } from "react";
import ChatPanel from "@/components/chat/ChatPanel";

// Thin shell around ChatPanel: a floating launcher (marketing pages) or an
// inline panel (dashboard). In floating mode the panel stays MOUNTED while
// closed (just hidden), so the conversation and any half-finished flow survive
// closing and reopening the bubble.
export default function ChatWidget({
  mode = "floating",
  title,
  loggedIn = false,
  userName,
  fleet = false,
}: {
  mode?: "floating" | "embedded";
  title?: string;
  loggedIn?: boolean;
  userName?: string;
  fleet?: boolean;
}) {
  const [open, setOpen] = useState(false);
  // Remount when the identity changes (login/logout) so history never leaks across users.
  const panelKey = loggedIn ? `u:${userName ?? ""}` : "guest";

  if (mode === "embedded") {
    return <ChatPanel key={panelKey} mode="embedded" title={title} loggedIn={loggedIn} userName={userName} fleet={fleet} />;
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end">
      <div className="mb-3" style={{ display: open ? "block" : "none" }}>
        <ChatPanel key={panelKey} mode="floating" title={title} loggedIn={loggedIn} userName={userName} fleet={fleet} onClose={() => setOpen(false)} />
      </div>
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg"
        style={{ background: "var(--gold)", color: "var(--bg)" }}
        aria-label={open ? "Close chat" : "Open chat"}
      >
        {open ? "✕" : "💬"}
      </button>
    </div>
  );
}
