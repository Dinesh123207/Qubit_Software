import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t mt-16" style={{ borderColor: "var(--border)" }}>
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 px-6 py-8 flex-wrap text-sm" style={{ color: "var(--text-muted)" }}>
        <span>QuantumOps — operational monitoring for quantum error correction</span>
        <div className="flex gap-5">
          <Link href="/product" className="no-underline hover:opacity-80">Product</Link>
          <Link href="/pricing" className="no-underline hover:opacity-80">Pricing</Link>
          <Link href="/about" className="no-underline hover:opacity-80">About</Link>
          <Link href="/contact" className="no-underline hover:opacity-80">Contact</Link>
        </div>
      </div>
    </footer>
  );
}
